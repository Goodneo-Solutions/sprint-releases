package ca.superroute.sprint.native

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import ca.superroute.sprint.core.Renderer
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Draws a PDF's first page (PdfRenderer) or an HTML page (an off-screen WebView
 * laid out at the printer's width, one CSS pixel per dot) into a PNG for the
 * core, which then scales, dithers and encodes it — the pixels the printer gets
 * are the Go core's, not the platform's.
 */
internal class AndroidRenderer(context: Context) : Renderer {
    private val ctx = context.applicationContext
    private val main = Handler(Looper.getMainLooper())

    override fun pdfToPng(pdf: ByteArray, widthDots: Long, heightDots: Long): ByteArray {
        val file = File.createTempFile("sprint-", ".pdf", ctx.cacheDir)
        try {
            file.writeBytes(pdf)
            ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { fd ->
                PdfRenderer(fd).use { r ->
                    if (r.pageCount == 0) throw IOException("the PDF has no page")
                    r.openPage(0).use { page ->
                        val w = if (widthDots > 0) widthDots.toInt() else page.width * 203 / 72
                        val h = (page.height.toLong() * w / page.width).toInt().coerceAtLeast(1)
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                        return png(bmp)
                    }
                }
            }
        } finally {
            file.delete()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun htmlToPng(html: String, baseURL: String, widthDots: Long, heightDots: Long): ByteArray {
        val width = if (widthDots > 0) widthDots.toInt() else 576
        val done = CountDownLatch(1)
        var result: ByteArray? = null
        var failure: String? = null
        main.post {
            try {
                val wv = WebView(ctx)
                wv.settings.javaScriptEnabled = true
                wv.setBackgroundColor(Color.WHITE)
                wv.setInitialScale(100)
                wv.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String?) {
                        // Let layout settle, then measure the content and draw it.
                        main.postDelayed({
                            try {
                                view.measure(
                                    View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                                )
                                val contentH = (view.contentHeight * view.resources.displayMetrics.density).toInt()
                                val h = when {
                                    heightDots > 0 -> heightDots.toInt()
                                    contentH > 0 -> contentH
                                    else -> view.measuredHeight.coerceAtLeast(1)
                                }.coerceIn(1, 20000)
                                view.layout(0, 0, width, h)
                                val bmp = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888)
                                bmp.eraseColor(Color.WHITE)
                                view.draw(Canvas(bmp))
                                result = png(bmp)
                            } catch (e: Exception) {
                                failure = e.message ?: e.toString()
                            } finally {
                                view.destroy()
                                done.countDown()
                            }
                        }, 300)
                    }
                }
                wv.layout(0, 0, width, 1)
                wv.loadDataWithBaseURL(baseURL.ifEmpty { null }, html, "text/html", "utf-8", null)
            } catch (e: Exception) {
                failure = e.message ?: e.toString()
                done.countDown()
            }
        }
        if (!done.await(30, TimeUnit.SECONDS)) throw IOException("HTML rendering timed out")
        failure?.let { throw IOException("render html: $it") }
        return result ?: throw IOException("render html: no image")
    }

    private fun png(bmp: Bitmap): ByteArray {
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        bmp.recycle()
        return out.toByteArray()
    }
}
