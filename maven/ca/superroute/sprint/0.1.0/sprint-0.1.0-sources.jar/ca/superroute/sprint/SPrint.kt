package ca.superroute.sprint

import android.content.Context
import ca.superroute.sprint.core.Core
import ca.superroute.sprint.native.AndroidRenderer
import ca.superroute.sprint.native.BleTransport
import ca.superroute.sprint.native.ClassicBluetoothTransport
import ca.superroute.sprint.native.UsbTransport
import org.json.JSONArray
import org.json.JSONObject

/**
 * sPrint, Superroute's printing SDK, on Android: encoding, printing, discovery and
 * identification, all done by the Go core. This layer only gives the core what
 * Android owns — Bluetooth (classic and LE), USB and the PDF / HTML renderer.
 * Call [init] once (an Application's onCreate is a good place) before printing to
 * Bluetooth, BLE or USB printers or printing PDF / HTML to a thermal printer.
 *
 * Every call blocks on I/O: call from a background thread or a coroutine on
 * Dispatchers.IO.
 */
object SPrint {
    @Volatile private var initialised = false

    /** Registers the native layer (transports bluetooth, ble, usb, the renderer and the device's subnets) with the core. */
    @JvmStatic
    fun init(context: Context) {
        if (initialised) return
        val ctx = context.applicationContext
        Core.registerTransport(Transports.BLUETOOTH, ClassicBluetoothTransport())
        Core.registerTransport(Transports.BLE, BleTransport(ctx))
        Core.registerTransport(Transports.USB, UsbTransport(ctx))
        Core.setRenderer(AndroidRenderer(ctx))
        Core.setPrefixProvider(ca.superroute.sprint.native.Prefixes(ctx))
        initialised = true
    }

    /** The version of the sPrint core. */
    @JvmStatic val version: String get() = Core.version()

    /** The command languages sPrint encodes into. */
    @JvmStatic val languages: List<String> get() = JSONArray(Core.languages()).strings()

    /** Cuts the print in flight; true when something was printing. */
    @JvmStatic fun stop(): Boolean = Core.stop()

    /** The bytes a label prints as on a printer (drawn at its resolution, in its language). */
    @JvmStatic
    fun encodeLabel(printer: TargetPrinter, label: LabelJob, copies: Int = 1): ByteArray =
        call { Core.encodeLabel(printer.toJson().toString(), label.toString(), copies.toLong()) }

    /** The bytes an image (PNG, JPEG, GIF) prints as on a thermal printer. */
    @JvmStatic
    fun encodeImage(printer: TargetPrinter, image: ByteArray, copies: Int = 1): ByteArray =
        call { Core.encodeImage(printer.toJson().toString(), image, copies.toLong()) }

    /** The one-line self-test in a language. */
    @JvmStatic fun selfTest(language: String, text: String): ByteArray = call { Core.selfTest(language, text) }

    /** Runs a job on a printer that is not (necessarily) in a registry. */
    @JvmStatic
    fun print(printer: TargetPrinter, job: PrintJob): PrintResult =
        PrintResult.fromJson(JSONObject(Core.print(printer.toJson().toString(), job.toJson().toString())))

    /** Works out a printer's language from what it goes by, without talking to it; null when nothing matched. */
    @JvmStatic
    fun identify(keys: PrinterKeys): PrinterIdentity? {
        val o = JSONObject(Core.identify(keys.toJson().toString()))
        o.optStringOrNull("error")?.let { throw SPrintException(it) }
        return if (o.optBoolean("ok")) o.optJSONObject("identity")?.let(PrinterIdentity::fromJson) else null
    }

    /** Asks a printer what it speaks without using paper; null when nothing answered. */
    @JvmStatic
    fun probeLanguage(printer: TargetPrinter): Probe? {
        val o = JSONObject(Core.probe(printer.toJson().toString()))
        o.optStringOrNull("error")?.let { throw SPrintException(it) }
        val p = o.optJSONObject("probe") ?: return null
        return Probe(p.optString("Language", p.optString("language")), p.optString("Evidence", p.optString("evidence")))
    }

    /** Loads a model table revision the server published; returns the active revision. */
    @JvmStatic fun loadModelTable(json: String): Int = call { Core.loadModelTable(json).toInt() }

    internal inline fun <T> call(block: () -> T): T = try {
        block()
    } catch (e: Exception) {
        throw SPrintException(e.message ?: e.toString())
    }
}
