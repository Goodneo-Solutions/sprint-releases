package ca.superroute.sprint

import ca.superroute.sprint.core.Core
import ca.superroute.sprint.core.EventHandler
import ca.superroute.sprint.core.Node
import ca.superroute.sprint.core.Registry
import org.json.JSONArray
import org.json.JSONObject

/**
 * The configured printers and the default one, kept in memory or in a file
 * ([path], e.g. `File(context.filesDir, "printers.json").path`). Jobs to one printer
 * run one at a time, in arrival order. Safe to use from any thread.
 */
class PrinterRegistry(path: String? = null) {
    internal val core: Registry = SPrint.call { Core.newRegistry(path ?: "") }

    private fun read(): JSONObject = JSONObject(core.list())

    /** The printers, by name. */
    val printers: List<TargetPrinter>
        get() {
            val a = read().optJSONArray("printers") ?: JSONArray()
            return (0 until a.length()).map { TargetPrinter.fromJson(a.getJSONObject(it)) }
        }

    /** The default printer's name, or null. */
    val defaultName: String? get() = read().optStringOrNull("default")

    /** A printer by its name. */
    operator fun get(name: String): TargetPrinter? = printers.firstOrNull { it.name == name }

    /** Adds or replaces a printer (the first saved becomes the default). */
    fun save(printer: TargetPrinter) = SPrint.call { core.save(printer.toJson().toString()) }

    /** Removes a printer. */
    fun remove(name: String) = SPrint.call { core.remove(name) }

    /** Makes a printer the default. */
    fun setDefault(name: String) = SPrint.call { core.setDefault(name) }

    /** Runs a job on the printer it names, or the default printer. */
    fun print(job: PrintJob): PrintResult = PrintResult.fromJson(JSONObject(core.print(job.toJson().toString())))

    /**
     * The fallback chain for label jobs (stream, raw, driver, html; a path that
     * fails twice is closed for that printer until it is back). Off by default.
     */
    var fallback: Boolean = false
        set(value) {
            core.setFallback(value)
            field = value
        }

    /** A printer's fallback chain state (JSON: closed, reason, since, next_check, last_path, last_ms). */
    fun fallbackState(name: String): JSONObject = JSONObject(core.fallbackState(name))

    /** Reopens every path of a printer's fallback chain. */
    fun resetFallback(name: String) = core.resetFallback(name)

    /** The superprinter.probe/1 report of a printer (JSON). */
    fun probeReport(name: String): String = SPrint.call { core.probeReport(name) }
}

/**
 * Turns this device into a Superroute print node: pairing (or headless
 * provisioning), the heartbeat with the registry's printers, jobs printed and
 * acknowledged, remote commands (diagnostics, probe report, protocol sweep) and
 * the MQTT doorbell. [onEvent] runs on a thread sPrint owns: hand work to your
 * own thread and return quickly. Persist every [NodeEvent.State] — it holds the
 * node token.
 */
class PrintNode(
    val registry: PrinterRegistry,
    state: NodeState? = null,
    deviceName: String? = null,
    agentVersion: String? = null,
    private val onEvent: (NodeEvent) -> Unit = {},
) {
    private val node: Node

    init {
        val config = JSONObject()
        state?.let { config.put("state", it.json) }
        val device = JSONObject().put("os", "android")
        deviceName?.let { device.put("hostname", it) }
        config.put("device", device)
        agentVersion?.let { config.put("agent_version", it) }
        node = SPrint.call {
            Core.newNode(config.toString(), registry.core, object : EventHandler {
                override fun onEvent(eventJSON: String) = dispatch(eventJSON)
            })
        }
    }

    private fun dispatch(json: String) {
        val o = runCatching { JSONObject(json) }.getOrNull() ?: return
        val ev = when (o.optString("type")) {
            "state" -> o.optJSONObject("state")?.let { NodeEvent.State(NodeState(it)) }
            "job" -> o.optJSONObject("result")?.let { NodeEvent.Job(o.optLong("job_id"), PrintResult.fromJson(it)) }
            "log" -> NodeEvent.Log(o.optString("message"))
            "sweep" -> o.optJSONObject("sweep")?.let { NodeEvent.Sweep(SweepView.fromJson(it)) }
            else -> null
        } ?: return
        runCatching { onEvent(ev) }
    }

    /** Redeems a pairing code (or activation code) from the Print Nodes page. */
    fun pair(code: String) = SPrint.call { node.pair(code) }

    /** Registers without a code; the node is claimed on the Print Nodes page. */
    fun provision() = SPrint.call { node.provision() }

    /** Sends one heartbeat now. */
    fun heartbeat() = SPrint.call { node.heartbeat() }

    /** Forgets the node token. */
    fun unpair() = node.unpair()

    /** Runs the node in the background until [stop]. Keep the process alive (a foreground service). */
    fun start() = SPrint.call { node.start() }

    /** Stops the background run. */
    fun stop() = node.stop()

    /** The node's state. */
    val state: NodeState get() = NodeState.parse(node.state())

    /** The node's status (JSON: state, last_beat, last_error, push). */
    val status: JSONObject get() = JSONObject(node.status())

    /** The protocol sweeps the node is running. */
    val sweeps: List<SweepView>
        get() {
            val a = JSONArray(node.sweeps())
            return (0 until a.length()).map { SweepView.fromJson(a.getJSONObject(it)) }
        }

    /** Next, Stop or a manual choice (action next | stop | choose) for a running sweep; the sweep's state (JSON). */
    fun sweepPress(sweep: Long, action: String, language: String? = null): JSONObject =
        JSONObject(SPrint.call { node.sweepPress(sweep, action, language ?: "") })
}
