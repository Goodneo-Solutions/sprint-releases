package ca.superroute.sprint.native

import android.content.Context
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import ca.superroute.sprint.core.Transport
import java.io.ByteArrayOutputStream
import java.io.IOException

/**
 * USB host (OTG): bulk OUT writes to the printer interface, bulk IN reads for
 * queries, the IEEE-1284 device ID through the printer class request. A
 * printer's host is "VID:PID[:SERIAL]" with the ids in hex, as on the desktops
 * (the SuperPrinter Android app's "usb:VID:PID" in decimal is read too). The
 * host asks for the device permission ([Usb.requestPermission]).
 */
internal class UsbTransport(context: Context) : Transport {
    private val ctx = context.applicationContext

    override fun send(targetJSON: String, data: ByteArray) {
        val (mgr, device) = Usb.open(ctx, Target.parse(targetJSON).host)
        val eps = Usb.endpoints(device) ?: throw IOException("no USB printer interface")
        val conn = mgr.openDevice(device) ?: throw IOException("can't open USB device")
        try {
            if (!conn.claimInterface(eps.intf, true)) throw IOException("can't claim USB interface")
            var off = 0
            while (off < data.size) {
                val n = minOf(16384, data.size - off)
                val sent = conn.bulkTransfer(eps.out, data, off, n, 5000)
                if (sent <= 0) throw IOException("USB write failed at offset $off")
                off += sent
            }
        } finally {
            runCatching { conn.releaseInterface(eps.intf) }
            runCatching { conn.close() }
        }
    }

    override fun query(targetJSON: String, cmd: ByteArray, quietMs: Long, overallMs: Long): ByteArray {
        val (mgr, device) = Usb.open(ctx, Target.parse(targetJSON).host)
        val eps = Usb.endpoints(device) ?: return ByteArray(0)
        val epIn = eps.input ?: return ByteArray(0)
        val conn = mgr.openDevice(device) ?: throw IOException("can't open USB device")
        try {
            if (!conn.claimInterface(eps.intf, true)) throw IOException("can't claim USB interface")
            conn.bulkTransfer(eps.out, cmd, cmd.size, 2000)
            val buf = ByteArray(4096)
            val out = ByteArrayOutputStream()
            val deadline = System.currentTimeMillis() + overallMs
            var last = System.currentTimeMillis()
            while (System.currentTimeMillis() < deadline) {
                val n = conn.bulkTransfer(epIn, buf, buf.size, 200)
                if (n > 0) {
                    out.write(buf, 0, n)
                    last = System.currentTimeMillis()
                } else if (out.size() > 0 && System.currentTimeMillis() - last >= quietMs) {
                    break
                }
            }
            return out.toByteArray()
        } finally {
            runCatching { conn.releaseInterface(eps.intf) }
            runCatching { conn.close() }
        }
    }

    override fun reachable(targetJSON: String): Boolean =
        runCatching { Usb.find(ctx, Target.parse(targetJSON).host)?.let { Usb.manager(ctx).hasPermission(it) } == true }.getOrDefault(false)
}

/** USB device lookup shared by the transport and discovery. */
object Usb {
    internal data class Eps(val intf: UsbInterface, val out: UsbEndpoint, val input: UsbEndpoint?)

    fun manager(ctx: Context) = ctx.getSystemService(Context.USB_SERVICE) as UsbManager

    /** The host string of a device: "vvvv:pppp[:serial]" in hex. */
    fun hostOf(device: UsbDevice): String {
        val serial = runCatching { device.serialNumber }.getOrNull()?.takeIf { it.isNotBlank() }
        val base = "%04x:%04x".format(device.vendorId, device.productId)
        return if (serial != null) "$base:$serial" else base
    }

    fun find(ctx: Context, host: String): UsbDevice? {
        val legacy = host.startsWith("usb:")
        val parts = host.removePrefix("usb:").split(":")
        val radix = if (legacy) 10 else 16
        val vid = parts.getOrNull(0)?.toIntOrNull(radix) ?: return null
        val pid = parts.getOrNull(1)?.toIntOrNull(radix) ?: return null
        val serial = parts.getOrNull(2)
        return manager(ctx).deviceList.values.firstOrNull { d ->
            d.vendorId == vid && d.productId == pid && (serial == null || runCatching { d.serialNumber }.getOrNull() == serial)
        }
    }

    internal fun open(ctx: Context, host: String): Pair<UsbManager, UsbDevice> {
        val mgr = manager(ctx)
        val device = find(ctx, host) ?: throw IOException("USB printer $host is not connected")
        if (!mgr.hasPermission(device)) throw IOException("USB permission not granted for $host")
        return mgr to device
    }

    internal fun endpoints(device: UsbDevice): Eps? {
        val ifaces = (0 until device.interfaceCount).map { device.getInterface(it) }
        for (intf in ifaces.sortedByDescending { it.interfaceClass == UsbConstants.USB_CLASS_PRINTER }) {
            var out: UsbEndpoint? = null
            var inp: UsbEndpoint? = null
            for (e in 0 until intf.endpointCount) {
                val ep = intf.getEndpoint(e)
                if (ep.type != UsbConstants.USB_ENDPOINT_XFER_BULK) continue
                if (ep.direction == UsbConstants.USB_DIR_OUT) { if (out == null) out = ep } else if (inp == null) inp = ep
            }
            if (out != null) return Eps(intf, out, inp)
        }
        return null
    }

    /** The printer's IEEE-1284 device ID (printer class GET_DEVICE_ID), or null. */
    fun deviceId(ctx: Context, device: UsbDevice): String? {
        val mgr = manager(ctx)
        if (!mgr.hasPermission(device)) return null
        val eps = endpoints(device) ?: return null
        if (eps.intf.interfaceClass != UsbConstants.USB_CLASS_PRINTER) return null
        val conn = mgr.openDevice(device) ?: return null
        return try {
            if (!conn.claimInterface(eps.intf, true)) return null
            val buf = ByteArray(1024)
            val n = conn.controlTransfer(0xA1, 0, 0, (eps.intf.id shl 8) or eps.intf.alternateSetting, buf, buf.size, 1000)
            if (n < 2) return null
            val len = (((buf[0].toInt() and 0xFF) shl 8) or (buf[1].toInt() and 0xFF)).coerceIn(2, n)
            String(buf, 2, len - 2, Charsets.ISO_8859_1).trim().ifBlank { null }
        } catch (_: Exception) {
            null
        } finally {
            runCatching { conn.releaseInterface(eps.intf) }
            runCatching { conn.close() }
        }
    }

    /** Asks the user to allow sPrint to use a USB printer; the answer arrives as a broadcast of [action]. */
    fun requestPermission(ctx: Context, device: UsbDevice, action: String = "ca.superroute.sprint.USB_PERMISSION") {
        val flags = if (android.os.Build.VERSION.SDK_INT >= 31) {
            android.app.PendingIntent.FLAG_MUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        } else {
            android.app.PendingIntent.FLAG_UPDATE_CURRENT
        }
        val pi = android.app.PendingIntent.getBroadcast(ctx, 0, android.content.Intent(action).setPackage(ctx.packageName), flags)
        manager(ctx).requestPermission(device, pi)
    }
}
