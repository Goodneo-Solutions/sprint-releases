package ca.superroute.sprint

import org.json.JSONArray
import org.json.JSONObject

/** Access modes of a [PeerHost]. */
object PeerModes {
    /** Anyone on the network. */
    const val OPEN = "open"
    /** Whoever gives the password. */
    const val PASSWORD = "password"
    /** The owner approves each new peer (the default). */
    const val APPROVAL = "approval"
}

/** Why a peer session ended ([PeerEvent.Disconnected.reason], [PeerEvent.Ended.reason]). */
object PeerReasons {
    const val DISCONNECTED = "disconnected"
    const val REVOKED = "revoked"
    const val EXPIRED = "expired"
    const val UNREACHABLE = "unreachable"
    const val STOPPED = "stopped"
}

/** Statuses of a [PeerSession]. */
object PeerStatuses {
    const val CONNECTED = "connected"
    const val PENDING = "pending"
    const val ENDED = "ended"
}

/** LAN peer printing constants (peer-direct protocol 1.1.0). */
object PeerProtocol {
    /** The mDNS service peers advertise (domain "local."). */
    const val SERVICE_TYPE = "_superprinter._tcp"
    /** The peer server's port unless told otherwise. */
    const val DEFAULT_PORT = 17778
    /** The registry transport of a connected peer's printer (target "peer:<fingerprint>/<printer>"). */
    const val TRANSPORT = "peer"

    /** The registry target name of a peer's printer. */
    @JvmStatic fun targetName(fingerprint: String, printer: String): String = "peer:${fingerprint.trim().lowercase()}/$printer"
}

/** A peer on a host's trust list (approved once, reconnects without asking). */
data class TrustedPeer(val fingerprint: String, val name: String? = null, val addedAt: String? = null) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("fingerprint", fingerprint)
        name?.let { put("name", it) }
        addedAt?.let { put("added_at", it) }
    }

    companion object {
        fun fromJson(o: JSONObject) = TrustedPeer(o.optString("fingerprint"), o.optStringOrNull("name"), o.optStringOrNull("added_at"))
    }
}

/**
 * What a [PeerHost] keeps between runs: store [toJson] on every [PeerEvent.State]
 * and hand it back to the next host. [seed] is the identity's Ed25519 seed
 * (base64): keep it private.
 */
data class PeerHostState(
    val seed: String? = null,
    /** open | password | approval (null = approval). */
    val mode: String? = null,
    /** The password mode's PBKDF2-SHA256 hash (the SuperPrinter agent's format). */
    val passwordHash: String? = null,
    /** The registry printers peers may see and print to. */
    val shared: List<String> = emptyList(),
    val trusted: List<TrustedPeer> = emptyList(),
    /** Advertised over mDNS while the host runs. */
    val discoverable: Boolean = false,
) {
    /** The access mode in force. */
    val modeOrDefault: String get() = mode?.takeIf { it == PeerModes.OPEN || it == PeerModes.PASSWORD || it == PeerModes.APPROVAL } ?: PeerModes.APPROVAL

    fun toJson(): JSONObject = JSONObject().apply {
        seed?.let { put("seed", it) }
        mode?.let { put("mode", it) }
        passwordHash?.let { put("password_hash", it) }
        if (shared.isNotEmpty()) put("shared", JSONArray(shared))
        if (trusted.isNotEmpty()) put("trusted", JSONArray(trusted.map { it.toJson() }))
        if (discoverable) put("discoverable", true)
    }

    override fun toString(): String = "PeerHostState(mode=$mode, shared=$shared, trusted=${trusted.size}, discoverable=$discoverable)"

    companion object {
        fun fromJson(o: JSONObject) = PeerHostState(
            o.optStringOrNull("seed"), o.optStringOrNull("mode"), o.optStringOrNull("password_hash"),
            o.optJSONArray("shared").strings(), o.optJSONArray("trusted").objects().map(TrustedPeer::fromJson),
            o.optBoolean("discoverable"),
        )

        /** Reads a stored state. */
        @JvmStatic fun parse(json: String) = fromJson(JSONObject(json))
    }
}

/** An approval request waiting for the owner ([PeerHost.decide]). */
data class PeerPending(val id: String, val fingerprint: String, val name: String?, val note: String?, val addr: String?, val requested: String) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id).put("fingerprint", fingerprint)
        name?.let { put("name", it) }
        note?.let { put("note", it) }
        addr?.let { put("addr", it) }
        put("requested", requested)
    }

    companion object {
        fun fromJson(o: JSONObject) = PeerPending(
            o.optString("id"), o.optString("fingerprint"), o.optStringOrNull("name"), o.optStringOrNull("note"),
            o.optStringOrNull("addr"), o.optString("requested"),
        )
    }
}

/** A peer connected to a host. [trusted]: admitted by the trust list, so a revoke ends it. */
data class PeerSessionInfo(val fingerprint: String, val name: String?, val addr: String?, val since: String, val expires: String, val trusted: Boolean) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("fingerprint", fingerprint)
        name?.let { put("name", it) }
        addr?.let { put("addr", it) }
        put("since", since).put("expires", expires)
        if (trusted) put("trusted", true)
    }

    companion object {
        fun fromJson(o: JSONObject) = PeerSessionInfo(
            o.optString("fingerprint"), o.optStringOrNull("name"), o.optStringOrNull("addr"), o.optString("since"),
            o.optString("expires"), o.optBoolean("trusted"),
        )
    }
}

/** A running host's status. */
data class PeerHostStatus(
    val running: Boolean,
    /** The address listened on ("0.0.0.0:17778", "127.0.0.1:41235"). */
    val addr: String?,
    val fingerprint: String,
    val name: String,
    val mode: String,
    val discoverable: Boolean,
    val advertising: Boolean,
    val advertiseError: String?,
    val sessions: Int,
    val pending: Int,
) {
    /** The port listened on (0 when not running). */
    val port: Int get() = addr?.substringAfterLast(':')?.toIntOrNull() ?: 0

    fun toJson(): JSONObject = JSONObject().apply {
        put("running", running)
        addr?.let { put("addr", it) }
        put("fingerprint", fingerprint).put("name", name).put("mode", mode)
        put("discoverable", discoverable).put("advertising", advertising)
        advertiseError?.let { put("advertise_error", it) }
        put("sessions", sessions).put("pending", pending)
    }

    companion object {
        fun fromJson(o: JSONObject) = PeerHostStatus(
            o.optBoolean("running"), o.optStringOrNull("addr"), o.optString("fingerprint"), o.optString("name"),
            o.optString("mode"), o.optBoolean("discoverable"), o.optBoolean("advertising"), o.optStringOrNull("advertise_error"),
            o.optInt("sessions"), o.optInt("pending"),
        )
    }
}

/**
 * A device advertising peer printing on the LAN ([SPrint.browsePeers]). Its fields
 * are hints for the UI: the authority is the fingerprint the connection proves.
 */
data class PeerAdvert(
    val fingerprint: String,
    val name: String,
    val mode: String,
    /** host:port ("192.168.1.20:17778", "[fd00::5]:17778"). */
    val addr: String,
    /** The peer's agent version (TXT agent). */
    val version: String,
    val instance: String?,
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("fingerprint", fingerprint).put("name", name).put("mode", mode).put("addr", addr).put("version", version)
        instance?.let { put("instance", it) }
    }

    companion object {
        fun fromJson(o: JSONObject) = PeerAdvert(
            o.optString("fingerprint"), o.optString("name"), o.optString("mode"), o.optString("addr"),
            o.optString("version"), o.optStringOrNull("instance"),
        )
    }
}

/** A peer's shared printer, as the peer lists it. */
data class PeerPrinter(
    val name: String,
    val isDefault: Boolean = false,
    val transport: String? = null,
    val language: String? = null,
    val widthDots: Int = 0,
    val dpi: Int = 0,
    val state: String? = null,
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("name", name).put("default", isDefault)
        transport?.let { put("transport", it) }
        language?.let { put("language", it) }
        if (widthDots != 0) put("width_dots", widthDots)
        if (dpi != 0) put("dpi", dpi)
        state?.let { put("state", it) }
    }

    companion object {
        fun fromJson(o: JSONObject) = PeerPrinter(
            o.optString("name"), o.optBoolean("default"), o.optStringOrNull("transport"), o.optStringOrNull("language"),
            o.optInt("width_dots"), o.optInt("dpi"), o.optStringOrNull("state"),
        )
    }
}

/** A session's status ([PeerStatuses]); [reason] says why it ended. */
data class PeerSessionStatus(
    val status: String,
    val reason: String?,
    val fingerprint: String,
    val name: String,
    val mode: String,
    val addr: String,
    /** The peer's agent version. */
    val version: String,
) {
    val connected: Boolean get() = status == PeerStatuses.CONNECTED
    val pending: Boolean get() = status == PeerStatuses.PENDING
    val ended: Boolean get() = status == PeerStatuses.ENDED

    fun toJson(): JSONObject = JSONObject().apply {
        put("status", status)
        reason?.let { put("reason", it) }
        put("fingerprint", fingerprint).put("name", name).put("mode", mode).put("addr", addr).put("version", version)
    }

    companion object {
        fun fromJson(o: JSONObject) = PeerSessionStatus(
            o.optString("status"), o.optStringOrNull("reason"), o.optString("fingerprint"), o.optString("name"),
            o.optString("mode"), o.optString("addr"), o.optString("version"),
        )
    }
}

/** What a [PeerHost] or a [PeerSession] reports. */
sealed class PeerEvent {
    /** Host: an approval request arrived. */
    data class Pending(val pending: PeerPending) : PeerEvent()
    /** Host: a peer was admitted. */
    data class Connected(val peer: PeerSessionInfo) : PeerEvent()
    /** Host: a peer's session ended ([PeerReasons]). */
    data class Disconnected(val peer: PeerSessionInfo?, val reason: String?) : PeerEvent()
    /** Host: the state to store changed. */
    data class State(val state: PeerHostState) : PeerEvent()
    /** Session: the peer ended it (revoked, expired, unreachable). */
    data class Ended(val fingerprint: String?, val name: String?, val reason: String?) : PeerEvent()
    /** Host: a log line. */
    data class Log(val message: String) : PeerEvent()

    companion object {
        /** An event from the core's JSON; null for a type this version does not know. */
        @JvmStatic
        fun fromJson(o: JSONObject): PeerEvent? = when (o.optString("type")) {
            "peer_pending" -> o.optJSONObject("pending")?.let { Pending(PeerPending.fromJson(it)) }
            "peer_connected" -> o.optJSONObject("peer")?.let { Connected(PeerSessionInfo.fromJson(it)) }
            "peer_disconnected" -> Disconnected(o.optJSONObject("peer")?.let(PeerSessionInfo::fromJson), o.optStringOrNull("reason"))
            "peer_state" -> o.optJSONObject("state")?.let { State(PeerHostState.fromJson(it)) }
            "peer_ended" -> Ended(o.optStringOrNull("fingerprint"), o.optStringOrNull("name"), o.optStringOrNull("reason"))
            "log" -> Log(o.optString("message"))
            else -> null
        }
    }
}

internal fun JSONArray?.objects(): List<JSONObject> = if (this == null) emptyList() else (0 until length()).map { getJSONObject(it) }
