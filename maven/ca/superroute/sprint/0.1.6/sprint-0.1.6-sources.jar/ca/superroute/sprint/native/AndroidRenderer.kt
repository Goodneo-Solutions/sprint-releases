package ca.superroute.sprint.native

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import ca.superroute.sprint.core.Renderer
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * Draws a PDF's first page (PdfRenderer) or an HTML page (an off-screen WebView
 * laid out at the printer's width, one CSS pixel per dot) into a PNG for the
 * core, which then scales, dithers and encodes it — the pixels the printer gets
 * are the Go core's, not the platform's.
 */
internal class AndroidRenderer(context: Context) : Renderer {
    private val ctx = context.applicationContext
    private val main = Handler(Looper.getMainLooper())

    override fun pdfToPng(pdf: ByteArray, widthDots: Long, heightDots: Long): ByteArray {
        val file = File.createTempFile("sprint-", ".pdf", ctx.cacheDir)
        try {
            file.writeBytes(pdf)
            ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { fd ->
                PdfRenderer(fd).use { r ->
                    if (r.pageCount == 0) throw IOException("the PDF has no page")
                    r.openPage(0).use { page ->
                        val w = if (widthDots > 0) widthDots.toInt() else page.width * 203 / 72
                        val h = (page.height.toLong() * w / page.width).toInt().coerceAtLeast(1)
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                        return png(bmp)
                    }
                }
            }
        } finally {
            file.delete()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun htmlToPng(html: String, baseURL: String, widthDots: Long, heightDots: Long): ByteArray {
        val width = if (widthDots > 0) widthDots.toInt() else 576
        // Two budgets: the first WebView in a process loads Chromium and starts its
        // renderer process before the page commits, which on a loaded device or
        // emulator has taken 40-100 s; the page itself then has PAGE_SECONDS.
        val committed = CountDownLatch(1)
        val done = CountDownLatch(1)
        val result = AtomicReference<ByteArray?>()
        val failure = AtomicReference<String?>()
        val webView = AtomicReference<WebView?>()
        val abandoned = AtomicBoolean(false)
        val drawing = AtomicBoolean(false)
        main.post {
            if (abandoned.get()) return@post
            try {
                val wv = WebView(ctx)
                webView.set(wv)
                wv.settings.javaScriptEnabled = true
                wv.setBackgroundColor(Color.WHITE)
                wv.setInitialScale(100)
                wv.webViewClient = object : WebViewClient() {
                    override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                        committed.countDown()
                    }

                    override fun onPageFinished(view: WebView, url: String?) {
                        committed.countDown()
                        if (!drawing.compareAndSet(false, true)) return
                        // Let layout settle, then measure the content and draw it.
                        main.postDelayed({
                            // Taken by whoever runs first: this draw, or the caller giving up.
                            val v = webView.getAndSet(null) ?: return@postDelayed
                            try {
                                v.measure(
                                    View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                                )
                                val contentH = (v.contentHeight * v.resources.displayMetrics.density).toInt()
                                val h = when {
                                    heightDots > 0 -> heightDots.toInt()
                                    contentH > 0 -> contentH
                                    else -> v.measuredHeight.coerceAtLeast(1)
                                }.coerceIn(1, 20000)
                                v.layout(0, 0, width, h)
                                val bmp = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888)
                                bmp.eraseColor(Color.WHITE)
                                v.draw(Canvas(bmp))
                                result.set(png(bmp))
                            } catch (e: Exception) {
                                failure.set(e.message ?: e.toString())
                            } finally {
                                v.destroy()
                                done.countDown()
                            }
                        }, 300)
                    }
                }
                wv.layout(0, 0, width, 1)
                wv.loadDataWithBaseURL(baseURL.ifEmpty { null }, html, "text/html", "utf-8", null)
            } catch (e: Exception) {
                failure.set(e.message ?: e.toString())
                webView.getAndSet(null)?.destroy()
                committed.countDown()
                done.countDown()
            }
        }
        val started = committed.await(STARTUP_SECONDS, TimeUnit.SECONDS)
        if (!started || !done.await(PAGE_SECONDS, TimeUnit.SECONDS)) {
            abandoned.set(true)
            main.post { webView.getAndSet(null)?.destroy() }
            throw IOException(
                if (started) "HTML rendering timed out"
                else "HTML rendering timed out: the WebView did not start in $STARTUP_SECONDS s",
            )
        }
        failure.get()?.let { throw IOException("render html: $it") }
        return result.get() ?: throw IOException("render html: no image")
    }

    private fun png(bmp: Bitmap): ByteArray {
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        bmp.recycle()
        return out.toByteArray()
    }

    private companion object {
        /** Until the page commits: loading Chromium and starting its renderer the first time. */
        const val STARTUP_SECONDS = 120L

        /** From the commit until the page is drawn. */
        const val PAGE_SECONDS = 30L
    }
}
