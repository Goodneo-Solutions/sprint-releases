package ca.superroute.sprint.native

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothSocket
import ca.superroute.sprint.core.Transport
import java.io.IOException
import java.util.UUID

/**
 * Classic Bluetooth (RFCOMM / Serial Port Profile): bytes straight to the socket.
 * Each job connects, writes in flushed 2 KiB chunks, waits for the link to drain
 * (~60 ms per KiB, 2.5–12 s) and closes, as the SuperPrinter Android engine does
 * (its kept link is off: not measured on classic printers). The host holds
 * BLUETOOTH_CONNECT (API 31+).
 */
@Suppress("DEPRECATION") // getDefaultAdapter keeps a Context out of the transport
internal class ClassicBluetoothTransport : Transport {
    private val spp: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val locks = HashMap<String, Any>()

    private fun lockFor(mac: String) = synchronized(locks) { locks.getOrPut(mac.uppercase()) { Any() } }

    @SuppressLint("MissingPermission")
    private fun connect(mac: String): BluetoothSocket {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: throw IOException("Bluetooth is not available")
        if (!adapter.isEnabled) throw IOException("Bluetooth is off")
        adapter.cancelDiscovery()
        val device = adapter.getRemoteDevice(mac)
        val secure = runCatching { device.createRfcommSocketToServiceRecord(spp).also { it.connect() } }
        secure.getOrNull()?.let { return it }
        // Some printers only take an insecure link.
        return runCatching { device.createInsecureRfcommSocketToServiceRecord(spp).also { it.connect() } }
            .getOrElse { throw IOException("connect $mac: ${secure.exceptionOrNull()?.message ?: it.message}") }
    }

    override fun send(targetJSON: String, data: ByteArray) {
        val t = Target.parse(targetJSON)
        synchronized(lockFor(t.host)) {
            val socket = connect(t.host)
            try {
                val out = socket.outputStream
                var off = 0
                while (off < data.size) {
                    val n = minOf(2048, data.size - off)
                    out.write(data, off, n)
                    out.flush()
                    off += n
                }
                Thread.sleep((data.size / 1024L * 60L).coerceIn(2500L, 12000L))
            } finally {
                runCatching { socket.close() }
            }
        }
    }

    override fun query(targetJSON: String, cmd: ByteArray, quietMs: Long, overallMs: Long): ByteArray {
        val t = Target.parse(targetJSON)
        synchronized(lockFor(t.host)) {
            val socket = connect(t.host)
            try {
                socket.outputStream.apply { write(cmd); flush() }
                val input = socket.inputStream
                val out = java.io.ByteArrayOutputStream()
                val buf = ByteArray(512)
                val deadline = System.currentTimeMillis() + overallMs
                var last = System.currentTimeMillis()
                while (System.currentTimeMillis() < deadline) {
                    if (input.available() > 0) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        last = System.currentTimeMillis()
                    } else {
                        if (out.size() > 0 && System.currentTimeMillis() - last >= quietMs) break
                        Thread.sleep(20)
                    }
                }
                return out.toByteArray()
            } finally {
                runCatching { socket.close() }
            }
        }
    }

    @SuppressLint("MissingPermission")
    override fun reachable(targetJSON: String): Boolean = runCatching {
        val mac = Target.parse(targetJSON).host
        BluetoothAdapter.getDefaultAdapter()?.bondedDevices?.any { it.address.equals(mac, ignoreCase = true) } == true
    }.getOrDefault(false)
}
