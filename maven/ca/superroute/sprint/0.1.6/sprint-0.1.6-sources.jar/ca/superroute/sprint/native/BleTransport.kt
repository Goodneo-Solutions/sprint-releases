package ca.superroute.sprint.native

import android.content.Context
import ca.superroute.sprint.core.Transport

/** Bluetooth LE (GATT, the 0xFF00 print service) for the core, over [BleLink]'s pooled sessions. */
internal class BleTransport(context: Context) : Transport {
    private val ctx = context.applicationContext

    override fun send(targetJSON: String, data: ByteArray) = BleLink.printRaw(ctx, Target.parse(targetJSON).host, data)

    override fun query(targetJSON: String, cmd: ByteArray, quietMs: Long, overallMs: Long): ByteArray =
        BleLink.query(ctx, Target.parse(targetJSON).host, cmd, overallMs) ?: ByteArray(0)

    override fun reachable(targetJSON: String): Boolean = BleLink.testConnection(ctx, Target.parse(targetJSON).host)
}
