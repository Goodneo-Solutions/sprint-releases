package ca.superroute.sprint.native

import android.annotation.TargetApi
import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import ca.superroute.sprint.core.MDNSAdvertiser
import ca.superroute.sprint.core.MDNSBrowser
import org.json.JSONObject
import java.net.InetAddress
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/*
 * mDNS for LAN peer printing through Android's NsdManager (design P6): on
 * Android 11 and later Go can neither list the interfaces nor join the
 * multicast group, so the core asks here. The browser lists _superprinter._tcp
 * and resolves each instance's address, port and TXT (fp, name, mode, v,
 * agent); the advertiser registers this device's instance with its TXT. A Wi-Fi
 * multicast lock is held while either is at work, so the Wi-Fi driver passes
 * multicast to the device.
 */

/** A reference-counted Wi-Fi multicast lock (CHANGE_WIFI_MULTICAST_STATE); a no-op without Wi-Fi. */
internal class PeerMulticast(context: Context) {
    private val lock: WifiManager.MulticastLock? = runCatching {
        val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager?
        wifi?.createMulticastLock("sprint-peer")?.apply { setReferenceCounted(false) }
    }.getOrNull()
    private var holders = 0

    /** Number of holders, for tests. */
    val held: Int @Synchronized get() = holders

    @Synchronized
    fun acquire() {
        if (holders++ == 0) runCatching { lock?.acquire() }
    }

    @Synchronized
    fun release() {
        if (holders == 0) return
        if (--holders == 0) runCatching { if (lock?.isHeld == true) lock.release() }
    }
}

private fun nsd(context: Context): NsdManager =
    context.applicationContext.getSystemService(Context.NSD_SERVICE) as NsdManager?
        ?: throw IllegalStateException("NsdManager is not available on this device")

private fun nsdError(what: String, code: Int): String {
    val name = when (code) {
        NsdManager.FAILURE_INTERNAL_ERROR -> "internal error"
        NsdManager.FAILURE_ALREADY_ACTIVE -> "already active"
        NsdManager.FAILURE_MAX_LIMIT -> "too many requests"
        else -> "error $code"
    }
    return "NSD $what failed: $name"
}

/** Browses _superprinter._tcp with NsdManager and resolves each instance (one at a time, as NSD wants before API 34). */
internal class NsdBrowser(context: Context, private val multicast: PeerMulticast) : MDNSBrowser {
    private val ctx = context.applicationContext
    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "sprint-nsd").apply { isDaemon = true } }

    override fun browse(timeoutMs: Long): String {
        val nsd = nsd(ctx)
        val timeout = if (timeoutMs > 0) timeoutMs else 3000
        val deadline = System.currentTimeMillis() + timeout
        val found = LinkedBlockingQueue<NsdServiceInfo>()
        val seen = HashSet<String>()
        val started = CountDownLatch(1)
        val stopped = CountDownLatch(1)
        var startError = 0
        val listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) = started.countDown()
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                startError = errorCode
                started.countDown()
                stopped.countDown()
            }
            override fun onDiscoveryStopped(serviceType: String) = stopped.countDown()
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) = stopped.countDown()
            override fun onServiceLost(service: NsdServiceInfo) {}
            override fun onServiceFound(service: NsdServiceInfo) {
                if (!MdnsService.sameType(service.serviceType)) return
                val first = synchronized(seen) { seen.add(service.serviceName) }
                if (first) found.offer(service)
            }
        }
        multicast.acquire()
        val out = ArrayList<MdnsService>()
        try {
            nsd.discoverServices(MdnsService.SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, listener)
            if (!started.await(timeout.coerceAtMost(5000), TimeUnit.MILLISECONDS)) {
                runCatching { nsd.stopServiceDiscovery(listener) }
                throw IllegalStateException("NSD discovery did not start")
            }
            if (startError != 0) throw IllegalStateException(nsdError("discovery", startError))
            // Resolve while listening; what is still queued at the deadline gets a short grace.
            val grace = deadline + RESOLVE_GRACE_MS
            while (true) {
                val now = System.currentTimeMillis()
                val info = if (now < deadline) found.poll(deadline - now, TimeUnit.MILLISECONDS) else found.poll()
                if (info == null) {
                    if (System.currentTimeMillis() >= deadline) break else continue
                }
                val left = (if (System.currentTimeMillis() < deadline) deadline else grace) - System.currentTimeMillis()
                if (left <= 0) break
                resolve(nsd, info, left.coerceAtMost(RESOLVE_TIMEOUT_MS))?.let { out.add(it) }
            }
        } finally {
            if (startError == 0) {
                runCatching { nsd.stopServiceDiscovery(listener) }
                stopped.await(1000, TimeUnit.MILLISECONDS)
            }
            multicast.release()
        }
        return MdnsService.listJson(out)
    }

    private fun resolve(nsd: NsdManager, info: NsdServiceInfo, timeoutMs: Long): MdnsService? =
        if (Build.VERSION.SDK_INT >= 34) resolveCallback(nsd, info, timeoutMs) else resolveLegacy(nsd, info, timeoutMs)

    @TargetApi(34)
    private fun resolveCallback(nsd: NsdManager, info: NsdServiceInfo, timeoutMs: Long): MdnsService? {
        val done = CountDownLatch(1)
        var got: MdnsService? = null
        val cb = object : NsdManager.ServiceInfoCallback {
            override fun onServiceInfoCallbackRegistrationFailed(errorCode: Int) = done.countDown()
            override fun onServiceUpdated(serviceInfo: NsdServiceInfo) {
                val s = runCatching { toService(serviceInfo, serviceInfo.hostAddresses) }.getOrNull()
                if (s != null && got == null) {
                    got = s
                    done.countDown()
                }
            }
            override fun onServiceLost() {}
            override fun onServiceInfoCallbackUnregistered() {}
        }
        try {
            nsd.registerServiceInfoCallback(info, executor, cb)
        } catch (_: Exception) {
            return null
        }
        done.await(timeoutMs, TimeUnit.MILLISECONDS)
        runCatching { nsd.unregisterServiceInfoCallback(cb) }
        return got
    }

    @Suppress("DEPRECATION")
    private fun resolveLegacy(nsd: NsdManager, info: NsdServiceInfo, timeoutMs: Long): MdnsService? {
        val until = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < until) {
            val done = CountDownLatch(1)
            var got: MdnsService? = null
            var error = 0
            nsd.resolveService(info, object : NsdManager.ResolveListener {
                override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                    error = errorCode
                    done.countDown()
                }
                override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
                    got = runCatching { toService(serviceInfo, listOfNotNull(serviceInfo.host)) }.getOrNull()
                    done.countDown()
                }
            })
            if (!done.await(until - System.currentTimeMillis(), TimeUnit.MILLISECONDS)) return null
            // Another app (or a resolve still winding down) holds NSD's single resolve: try again.
            if (error == NsdManager.FAILURE_ALREADY_ACTIVE) {
                Thread.sleep(100)
                continue
            }
            return got
        }
        return null
    }

    private fun toService(info: NsdServiceInfo, addrs: List<InetAddress>): MdnsService? {
        val host = MdnsService.pickAddress(addrs)
        if (host.isEmpty() || info.port <= 0) return null
        return MdnsService(
            instance = info.serviceName, host = host, port = info.port,
            txt = MdnsService.txtFromAttributes(info.attributes),
        )
    }

    private companion object {
        const val RESOLVE_TIMEOUT_MS = 3000L
        const val RESOLVE_GRACE_MS = 1500L
    }
}

/** Registers this device's _superprinter._tcp instance with NsdManager, with its TXT record. */
internal class NsdAdvertiser(context: Context, private val multicast: PeerMulticast) : MDNSAdvertiser {
    private val ctx = context.applicationContext
    private val registrations = HashMap<String, Registration>()

    private class Registration : NsdManager.RegistrationListener {
        val registered = CountDownLatch(1)
        val unregistered = CountDownLatch(1)
        @Volatile var error = 0
        override fun onServiceRegistered(serviceInfo: NsdServiceInfo) = registered.countDown()
        override fun onRegistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
            error = errorCode
            registered.countDown()
        }
        override fun onServiceUnregistered(serviceInfo: NsdServiceInfo) = unregistered.countDown()
        override fun onUnregistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) = unregistered.countDown()
    }

    /** The instances registered now, for tests. */
    val instances: Set<String> @Synchronized get() = registrations.keys.toSet()

    @Synchronized
    override fun advertise(serviceJSON: String) {
        val svc = MdnsService.fromJson(JSONObject(serviceJSON))
        require(svc.instance.isNotEmpty()) { "an mDNS service needs an instance name" }
        require(svc.port in 1..65535) { "an mDNS service needs a port" }
        val nsd = nsd(ctx)
        // A later call for the same instance replaces it: withdraw the old one first,
        // so NSD does not rename the new one as a conflict.
        registrations.remove(svc.instance)?.let { unregister(nsd, it) }
        val info = NsdServiceInfo().apply {
            serviceName = svc.instance
            serviceType = svc.service
            port = svc.port
            for ((k, v) in svc.attributes) runCatching { setAttribute(k, MdnsService.fitValue(k, v)) }
        }
        val reg = Registration()
        multicast.acquire()
        try {
            nsd.registerService(info, NsdManager.PROTOCOL_DNS_SD, reg)
        } catch (e: Exception) {
            multicast.release()
            throw e
        }
        if (!reg.registered.await(REGISTER_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
            runCatching { nsd.unregisterService(reg) }
            multicast.release()
            throw IllegalStateException("NSD registration did not answer")
        }
        if (reg.error != 0) {
            multicast.release()
            throw IllegalStateException(nsdError("registration", reg.error))
        }
        registrations[svc.instance] = reg
    }

    @Synchronized
    override fun withdraw(instance: String) {
        val reg = registrations.remove(instance) ?: return
        unregister(nsd(ctx), reg)
    }

    private fun unregister(nsd: NsdManager, reg: Registration) {
        try {
            nsd.unregisterService(reg)
            reg.unregistered.await(UNREGISTER_TIMEOUT_MS, TimeUnit.MILLISECONDS)
        } catch (_: Exception) {
        } finally {
            multicast.release()
        }
    }

    private companion object {
        const val REGISTER_TIMEOUT_MS = 5000L
        const val UNREGISTER_TIMEOUT_MS = 2000L
    }
}
