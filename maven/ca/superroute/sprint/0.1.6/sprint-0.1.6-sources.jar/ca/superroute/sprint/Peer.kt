package ca.superroute.sprint

import ca.superroute.sprint.core.Core
import ca.superroute.sprint.core.EventHandler
import org.json.JSONArray
import org.json.JSONObject
import ca.superroute.sprint.core.PeerHost as CoreHost
import ca.superroute.sprint.core.PeerIdentity as CoreIdentity
import ca.superroute.sprint.core.PeerSession as CoreSession

/*
 * LAN peer printing (docs/LAN-PEER-DESIGN.md): two devices on one network print
 * to each other's shared printers with no server, over the peer-direct profile
 * of ODEP (protocol 1.1.0) the SuperPrinter apps speak. A [PeerHost] shares this
 * device's printers; [SPrint.connectPeer] opens a [PeerSession] to another
 * device's; [SPrint.browsePeers] lists the devices advertising on the LAN. mDNS
 * goes through Android's NsdManager, registered with the core by [SPrint.init].
 *
 * Every call blocks on the network: call from a background thread or a
 * coroutine on Dispatchers.IO. Events run on a thread sPrint owns: hand work to
 * your own thread and return quickly.
 */

/**
 * This device's identity on the LAN: an Ed25519 key whose [fingerprint] peers
 * pin. Store [seed] (privately) and rebuild the identity with [fromSeed].
 */
class PeerIdentity private constructor(internal val core: CoreIdentity) {
    /** The identity's seed (base64), to store. */
    val seed: String get() = core.seed()

    /** The protocol's fingerprint ("a1b2:c3d4:…", 8 groups of 4 hex digits). */
    val fingerprint: String get() = core.fingerprint()

    /** The fingerprint's first eight hex digits, for display. */
    val shortFingerprint: String get() = fingerprint.replace(":", "").take(8)

    override fun toString(): String = "PeerIdentity($fingerprint)"

    companion object {
        /** A fresh identity. */
        @JvmStatic fun create(): PeerIdentity = PeerIdentity(SPrint.call { Core.newPeerIdentity("") })

        /** The identity of a stored seed (base64). */
        @JvmStatic fun fromSeed(seed: String): PeerIdentity {
            require(seed.isNotEmpty()) { "an empty seed" }
            return PeerIdentity(SPrint.call { Core.newPeerIdentity(seed) })
        }
    }
}

/**
 * Shares this device's printers with peers on the LAN. Off until [start]; shares
 * nothing until [setShared]; approval mode unless [state] or [setMode] says
 * otherwise. Store every [PeerEvent.State] and hand it back as [state] next time.
 *
 * Jobs a peer sends are printed through [registry] exactly as a local job, on the
 * shared printers only.
 *
 * @param name shown to peers (hello, mDNS); null = the device's host name.
 * @param port the server's port (0 = 17778) on every interface.
 * @param bindAddr the "host:port" listened on instead of [port] ("127.0.0.1:0" in tests).
 * @param identity the device's identity; null takes [state]'s seed, else a new one (handed over in a [PeerEvent.State]).
 * @param agentVersion advertised to peers (null = "sprint/<version>").
 */
class PeerHost(
    val registry: PrinterRegistry,
    name: String? = null,
    state: PeerHostState? = null,
    identity: PeerIdentity? = null,
    port: Int = 0,
    bindAddr: String? = null,
    agentVersion: String? = null,
    private val onEvent: (PeerEvent) -> Unit = {},
) : AutoCloseable {
    private val host: CoreHost

    init {
        val config = JSONObject()
        name?.let { config.put("name", it) }
        if (port != 0) config.put("port", port)
        bindAddr?.let { config.put("bind_addr", it) }
        state?.let { config.put("state", it.toJson()) }
        agentVersion?.let { config.put("agent_version", it) }
        host = SPrint.call {
            Core.newPeerHost(config.toString(), registry.core, identity?.core, object : EventHandler {
                override fun onEvent(eventJSON: String) = dispatch(eventJSON, onEvent)
            })
        }
    }

    /** Opens the server (and advertises it when discoverable). */
    fun start() = SPrint.call { host.start() }

    /** Closes the server and ends every session. */
    fun stop() = host.stop()

    /** Same as [stop]. */
    override fun close() = stop()

    /** Sets the access mode ([PeerModes]). */
    fun setMode(mode: String) = SPrint.call { host.setMode(mode) }

    /** Sets the password of password mode (null or "" clears it). */
    fun setPassword(password: String?) = SPrint.call { host.setPassword(password ?: "") }

    /** Sets the shared printers (registry names). */
    fun setShared(names: List<String>) = SPrint.call { host.setShared(JSONArray(names).toString()) }

    /** Turns the mDNS advertisement on or off (browsing and connecting out are unaffected). */
    fun setDiscoverable(on: Boolean) = SPrint.call { host.setDiscoverable(on) }

    /** The approval requests waiting. */
    val pending: List<PeerPending> get() = jsonObjects(host.pending()).map(PeerPending::fromJson)

    /** Approves or refuses a request; an approved fingerprint joins the trust list. */
    fun decide(id: String, approve: Boolean) = SPrint.call { host.decide(id, approve) }

    /** The connected peers. */
    val sessions: List<PeerSessionInfo> get() = jsonObjects(host.sessions()).map(PeerSessionInfo::fromJson)

    /** Takes a peer off the trust list and ends its sessions at once. */
    fun revoke(fingerprint: String) = SPrint.call { host.revoke(fingerprint) }

    /** The state to store. */
    val state: PeerHostState get() = PeerHostState.parse(host.state())

    /** The host's status. */
    val status: PeerHostStatus get() = PeerHostStatus.fromJson(JSONObject(host.status()))

    /** This host's fingerprint. */
    val fingerprint: String get() = status.fingerprint
}

/**
 * A connection to a peer's shared printers, from [SPrint.connectPeer]. It is
 * connected at once (open mode, the password, or a peer that trusts this
 * device), or waits for the owner's approval ([status] pending: call
 * [waitApproval]). It keeps itself alive (ping every 8 s); a revoke, an expiry
 * or the peer leaving ends it with a [PeerEvent.Ended].
 */
class PeerSession internal constructor(internal val core: CoreSession) : AutoCloseable {
    /** The session's status. */
    val status: PeerSessionStatus get() = PeerSessionStatus.fromJson(JSONObject(core.status()))

    /** The peer's fingerprint, as its certificate proved it. */
    val fingerprint: String get() = status.fingerprint

    /** Waits for the owner's decision (0 = two minutes); throws when refused or not answered in time. */
    fun waitApproval(timeoutMs: Long = 0) = SPrint.call { core.waitApproval(timeoutMs) }

    /** The peer's shared printers. */
    val printers: List<PeerPrinter>
        get() = jsonObjects(SPrint.call { core.printers() }).map(PeerPrinter::fromJson)

    /**
     * The registry target names of the peer's shared printers
     * ("peer:<fingerprint>/<printer>"), as [PrinterRegistry.attachPeer] adds them.
     */
    val targetNames: List<String> get() = fingerprint.let { fp -> printers.map { PeerProtocol.targetName(fp, it.name) } }

    /** Runs a job on a shared printer (null = the peer's default shared printer). */
    fun print(printer: String?, job: PrintJob): PrintResult =
        PrintResult.fromJson(JSONObject(core.print(printer ?: "", job.toJson().toString())))

    /** Ends the session from this side. */
    fun disconnect() = core.disconnect()

    /** Same as [disconnect]. */
    override fun close() = disconnect()
}

internal fun dispatch(json: String, onEvent: (PeerEvent) -> Unit) {
    val o = runCatching { JSONObject(json) }.getOrNull() ?: return
    val ev = PeerEvent.fromJson(o) ?: return
    runCatching { onEvent(ev) }
}

/** Browsing and connecting, in [SPrint]. */
internal object Peers {
    fun browse(timeoutMs: Long): List<PeerAdvert> {
        val o = JSONObject(Core.browsePeers(timeoutMs))
        o.optStringOrNull("error")?.let { throw SPrintException(it) }
        return o.optJSONArray("peers").objects().map(PeerAdvert::fromJson)
    }

    fun connect(
        addr: String,
        identity: PeerIdentity,
        fingerprint: String?,
        password: String?,
        note: String?,
        pingMs: Long,
        onEvent: (PeerEvent) -> Unit,
    ): PeerSession {
        val o = JSONObject().put("addr", addr)
        fingerprint?.let { o.put("fingerprint", it) }
        password?.let { o.put("password", it) }
        note?.let { o.put("note", it) }
        if (pingMs > 0) o.put("ping_ms", pingMs)
        val handler = object : EventHandler {
            override fun onEvent(eventJSON: String) = dispatch(eventJSON, onEvent)
        }
        return PeerSession(SPrint.call { Core.connectPeer(o.toString(), identity.core, handler) })
    }
}

/** The objects of a JSON array ("null" or "" = none). */
internal fun jsonObjects(json: String?): List<JSONObject> {
    val t = json?.trim().orEmpty()
    if (t.isEmpty() || t == "null") return emptyList()
    val a = JSONArray(t)
    return (0 until a.length()).mapNotNull { a.optJSONObject(it) }
}
