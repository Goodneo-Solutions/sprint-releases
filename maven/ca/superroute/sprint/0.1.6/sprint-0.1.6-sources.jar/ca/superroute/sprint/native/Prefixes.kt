package ca.superroute.sprint.native

import android.content.Context
import android.net.ConnectivityManager
import ca.superroute.sprint.core.PrefixProvider
import org.json.JSONArray
import java.net.Inet4Address

/**
 * The device's private IPv4 /24 prefixes, read from ConnectivityManager: on
 * Android 11 and later apps may not list network interfaces the way Go does,
 * so the core asks here for the subnets a network scan looks at.
 */
internal class Prefixes(context: Context) : PrefixProvider {
    private val ctx = context.applicationContext

    override fun localPrefixes(): String {
        val out = LinkedHashSet<String>()
        runCatching {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            @Suppress("DEPRECATION")
            val networks = cm.allNetworks
            for (n in networks) {
                val lp = cm.getLinkProperties(n) ?: continue
                for (la in lp.linkAddresses) {
                    val a = la.address
                    if (a is Inet4Address && a.isSiteLocalAddress) {
                        a.hostAddress?.substringBeforeLast('.')?.let { out.add(it) }
                    }
                }
            }
        }
        return JSONArray(out.toList()).toString()
    }
}
