package ca.superroute.sprint.native

import org.json.JSONObject

/** The two fields of a target the transports read. */
internal data class Target(val name: String, val host: String, val channel: Int) {
    companion object {
        fun parse(json: String): Target {
            val o = JSONObject(json)
            return Target(o.optString("name"), o.optString("host"), o.optInt("channel"))
        }
    }
}
