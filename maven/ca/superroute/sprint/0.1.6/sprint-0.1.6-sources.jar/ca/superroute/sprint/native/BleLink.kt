package ca.superroute.sprint.native

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.util.Log
import java.io.IOException
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

/**
 * Taken from the SuperPrinter Android engine's BlePrinter (frozen there, S5) with
 * the stop token and the probe-report recording removed: the Go core stops a job
 * between its own writes and writes its own probe report.
 *
 * Bluetooth Low Energy printing for GATT-based thermal printers (Phomemo M832 /
 * M08F family and any printer exposing the same service). The print bytes are the
 * same XPP raster as USB; only the link differs.
 *
 * Protocol (reverse-engineered, matches the desktop agent): the print service is
 * vendor UUID **0xFF00**, characteristic **0xFF02** is the data sink (write
 * without response) and **0xFF03** delivers status notifications. The printer only
 * acts on FF02 writes AFTER the central has subscribed to FF03 (the CCCD write
 * "opens" the pipe), and the per-chunk write must be paced or the printer drops
 * the tail (only the top of the image prints).
 *
 * Android's GATT API is callback-based; this wraps it into blocking calls with
 * latches. Call off the main thread. Requires BLUETOOTH_CONNECT (API 31+).
 */
internal object BleLink {
    private const val TAG = "BlePrinter"

    private val SVC_PRINT = UUID.fromString("0000ff00-0000-1000-8000-00805f9b34fb")
    private val CH_WRITE = UUID.fromString("0000ff02-0000-1000-8000-00805f9b34fb")
    private val CH_NOTIFY = UUID.fromString("0000ff03-0000-1000-8000-00805f9b34fb")
    private val CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

    private const val PACE_MS = 10L
    private const val MAX_CHUNK = 180

    // ---- connection pool ----
    //
    // A BLE print used to connect, discover services, subscribe, write and
    // disconnect — every job. Now the session to a printer stays open while jobs
    // keep coming (closed after IDLE_CLOSE_MS idle); the wait the printer needs
    // before a disconnect is paid once, when the session closes. Notifications are
    // subscribed once per session (the subscription is also what opens the data
    // pipe). Prints and queries share the session, one caller at a time.

    private const val IDLE_CLOSE_MS = 10_000L
    private const val DRAIN_BEFORE_DISCONNECT_MS = 300L

    private class Slot {
        var session: Session? = null
        var lastUse = 0L
        var lastWrite = 0L
        var closer: ScheduledFuture<*>? = null
        /** The printer has answered the XPP status query on this session. */
        var answered = false
    }

    private val slots = HashMap<String, Slot>()
    private val timer = Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "ble-idle-close").apply { isDaemon = true }
    }

    private fun slotFor(mac: String): Slot = synchronized(slots) { slots.getOrPut(mac) { Slot() } }

    /** Make sure the slot holds a live, subscribed session; true when one was reused. */
    private fun Slot.open(ctx: Context, mac: String): Boolean {
        session?.let { if (it.connected) return true }
        drop()
        val s = connectSession(ctx, mac)
        try {
            s.subscribeNotify()
        } catch (e: Exception) {
            s.close()
            throw e
        }
        session = s
        return false
    }

    private fun Slot.drop() {
        closer?.cancel(false)
        closer = null
        session?.close()
        session = null
        answered = false
    }

    private fun Slot.closeDrained() {
        if (session == null) return
        val wait = DRAIN_BEFORE_DISCONNECT_MS - (System.currentTimeMillis() - lastWrite)
        if (lastWrite > 0 && wait > 0) Thread.sleep(wait)
        drop()
    }

    private fun Slot.touch(mac: String) {
        lastUse = System.currentTimeMillis()
        closer?.cancel(false)
        closer = timer.schedule({
            synchronized(this) {
                if (session != null && System.currentTimeMillis() - lastUse >= IDLE_CLOSE_MS) {
                    Log.i(TAG, "closing idle ble session to $mac")
                    closeDrained()
                }
            }
        }, IDLE_CLOSE_MS, TimeUnit.MILLISECONDS)
    }

    /** Writes [data] paced in chunks; returns the bytes written before any failure. */
    private fun Session.writeAll(data: ByteArray): Int {
        var off = 0
        while (off < data.size) {
            val n = minOf(chunk, data.size - off)
            try {
                write(data, off, n)
            } catch (e: IOException) {
                throw PartialWrite(off, e)
            }
            off += n
            Thread.sleep(PACE_MS)
        }
        return off
    }

    private class PartialWrite(val written: Int, cause: IOException) : IOException(cause.message, cause)

    /**
     * Encode-agnostic: write raw printer bytes to the BLE printer at [mac] over its
     * pooled session, returning once they are written. A session the printer
     * dropped while idle fails on its first chunk with nothing delivered; only that
     * case reconnects and writes once more — re-sending after bytes went out could
     * print a label twice.
     */
    fun printRaw(ctx: Context, mac: String, data: ByteArray) {
        val slot = slotFor(mac)
        try {
            synchronized(slot) {
                var reused = slot.open(ctx, mac)
                if (reused && !slot.readyForNext(data)) {
                    // The kept session is dead (printer switched off or rebooted);
                    // a fresh connect fails at once when the printer is gone.
                    Log.i(TAG, "kept ble session to $mac is not answering; reconnecting")
                    slot.drop()
                    slot.open(ctx, mac)
                    reused = false
                }
                try {
                    slot.session!!.writeAll(data)
                } catch (e: PartialWrite) {
                    if (!reused || e.written > 0) {
                        slot.drop()
                        throw e.cause ?: e
                    }
                    Log.i(TAG, "idle ble session to $mac was dropped; reconnecting")
                    slot.drop()
                    slot.open(ctx, mac)
                    try {
                        slot.session!!.writeAll(data)
                    } catch (e2: PartialWrite) {
                        slot.drop()
                        throw e2.cause ?: e2
                    }
                }
                slot.lastWrite = System.currentTimeMillis()
                if (isXppJob(data)) slot.confirmPrinted()
                slot.touch(mac)
            }
        } finally {
        }
    }

    // ---- pacing and acknowledgement on a kept session ----
    //
    // Measured on a Phomemo M832 (2026-10-07, Go agent, same printer protocol):
    // the printer buffers one job while it prints and stays silent to its status
    // query until it is done — five labels sent back to back printed two — and a
    // write to a session the printer dropped (switched off) "succeeds" with the
    // label lost. A per-job connect hid both. So an XPP job is checked with the
    // printer's own status before (ready) and after (printed) it, as in the Go
    // agent's internal/printer/ble/pool.go.

    /** Prefix of [Unconfirmed] messages, for callers that only see the error text. */
    const val UNCONFIRMED = "ble: the printer did not confirm the job"

    /**
     * An XPP job was written but the printer never reported it done (switched
     * off, out of paper, link lost while printing). It may have printed, so it
     * must not be sent again automatically.
     */
    class Unconfirmed(detail: String) : IOException("$UNCONFIRMED: $detail")

    private const val XPP_IDLE_TIMEOUT_MS = 15_000L
    /** Spacing for an XPP printer that never answers: what the per-job connect gave. */
    private const val SILENT_GAP_MS = 4_000L
    private val XPP_STATUS = byteArrayOf(0x1f, 0x11, 0x07)

    /** Every XPP job opens with `1F 11`. */
    private fun isXppJob(data: ByteArray) = data.size >= 2 && data[0] == 0x1f.toByte() && data[1] == 0x11.toByte()

    private fun xppReply(r: ByteArray?) = r != null && r.size >= 3 && r[0] == 0x1a.toByte() && r[1] == 0x07.toByte()
    private fun xppIdle(r: ByteArray?) = xppReply(r) && r!![2] == 0x02.toByte()

    /** One XPP status exchange on the open session: the `1A 07 …` frame, or null. */
    private fun Slot.status(): ByteArray? {
        val s = session ?: throw IOException("ble: link dropped")
        s.notifications.clear()
        s.write(XPP_STATUS, 0, XPP_STATUS.size)
        val deadline = System.currentTimeMillis() + 300
        while (System.currentTimeMillis() < deadline) {
            val frame = s.notifications.poll(60, TimeUnit.MILLISECONDS) ?: continue
            if (frame.isNotEmpty() && frame[0] == 0x1a.toByte()) return frame
        }
        return null
    }

    /**
     * Before the next job on a kept session; false means the session is dead and
     * must be reconnected. A printer that answers its status must say idle
     * ([confirmPrinted] left it idle, so silence now means the link is gone); one
     * that never answers gets [SILENT_GAP_MS] after its last job. Any other job
     * waits out the drain a disconnect used to give.
     */
    private fun Slot.readyForNext(data: ByteArray): Boolean {
        val since = System.currentTimeMillis() - lastWrite
        if (!isXppJob(data)) {
            if (lastWrite > 0 && since < DRAIN_BEFORE_DISCONNECT_MS) Thread.sleep(DRAIN_BEFORE_DISCONNECT_MS - since)
            return true
        }
        if (!answered) {
            if (lastWrite > 0 && since < SILENT_GAP_MS) Thread.sleep(SILENT_GAP_MS - since)
            return true
        }
        val deadline = System.currentTimeMillis() + XPP_IDLE_TIMEOUT_MS
        var silent = 0
        while (System.currentTimeMillis() < deadline) {
            val r = try { status() } catch (e: IOException) { return false }
            when {
                xppIdle(r) -> return true
                xppReply(r) -> silent = 0 // answering but busy / not ready: keep waiting
                else -> if (++silent >= 3) return false
            }
            Thread.sleep(150)
        }
        return false
    }

    /**
     * After an XPP job, wait for the printer to report idle again — it stays
     * silent while printing. That is the job's acknowledgement and its pacing.
     */
    private fun Slot.confirmPrinted() {
        val start = System.currentTimeMillis()
        while (System.currentTimeMillis() - start < XPP_IDLE_TIMEOUT_MS) {
            Thread.sleep(200)
            val r = try {
                status()
            } catch (e: IOException) {
                drop()
                throw Unconfirmed("link lost while printing: ${e.message}")
            }
            if (xppReply(r)) {
                answered = true
                if (xppIdle(r)) return
                continue
            }
            // A printer that has never answered cannot confirm; it gets the
            // spacing the per-job connect used to give, as before.
            if (!answered && System.currentTimeMillis() - start >= SILENT_GAP_MS) return
        }
        drop()
        throw Unconfirmed("within ${XPP_IDLE_TIMEOUT_MS / 1000} s (switched off or out of paper?)")
    }

    /** Write a status command and return the first framed reply (`1A …`), or null. */
    fun query(ctx: Context, mac: String, command: ByteArray, overallMs: Long = 2500): ByteArray? {
        val slot = slotFor(mac)
        return synchronized(slot) {
            try {
                slot.open(ctx, mac)
                val session = slot.session!!
                session.notifications.clear() // an earlier, unread frame is not this reply
                session.write(command, 0, command.size)
                slot.touch(mac)
                var reply: ByteArray? = null
                val deadline = System.currentTimeMillis() + overallMs
                while (System.currentTimeMillis() < deadline) {
                    val frame = session.notifications.poll(300, TimeUnit.MILLISECONDS) ?: continue
                    if (frame.isNotEmpty() && frame[0] == 0x1a.toByte()) {
                        reply = frame
                        break
                    }
                }
                reply
            } catch (e: IOException) {
                slot.drop()
                throw e
            }
        }
    }

    /** Quick reachability check: a session is open or can be opened (stays pooled). */
    fun testConnection(ctx: Context, mac: String): Boolean {
        val slot = slotFor(mac)
        return synchronized(slot) {
            try {
                slot.open(ctx, mac)
                slot.touch(mac)
                true
            } catch (_: Exception) {
                slot.drop()
                false
            }
        }
    }

    /** Whether a pooled session to [mac] is open now. */
    fun sessionOpen(mac: String): Boolean = synchronized(slots) { slots[mac] }?.session?.connected == true

    /** Drain and close every pooled session (the engine is shutting down). */
    fun closeAll() {
        val all = synchronized(slots) { slots.values.toList() }
        all.forEach { synchronized(it) { it.closeDrained() } }
    }

    // --- GATT session plumbing ---

    private class Session(
        val gatt: BluetoothGatt,
        val write: BluetoothGattCharacteristic,
        val notify: BluetoothGattCharacteristic,
    ) {
        val notifications = LinkedBlockingQueue<ByteArray>()
        var writeLatch = CountDownLatch(0)
        var cccdLatch = CountDownLatch(1)
        /** Bytes per write: the negotiated ATT MTU less 3, at most 180 (larger writes overrun the M832's buffer and drop the link). */
        @Volatile var chunk = 20
        val mtuLatch = CountDownLatch(1)
        @Volatile var cccdStatus = BluetoothGatt.GATT_SUCCESS

        /** Cleared by the GATT callback when the printer drops the link. */
        @Volatile var connected = true

        @SuppressLint("MissingPermission")
        fun close() {
            connected = false
            runCatching { gatt.disconnect() }
            runCatching { gatt.close() }
        }

        @SuppressLint("MissingPermission")
        fun subscribeNotify() {
            gatt.setCharacteristicNotification(notify, true)
            val cccd = notify.getDescriptor(CCCD) ?: throw IOException("ble: the notify characteristic has no CCCD")
            cccd.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            if (!gatt.writeDescriptor(cccd)) throw IOException("ble: enable notifications rejected")
            // A printer that wants an encrypted link (Phomemo M832) makes Android
            // ask the user to pair on this write: wait for the answer when the
            // phone is not bonded with it yet.
            val bonded = runCatching { gatt.device.bondState == android.bluetooth.BluetoothDevice.BOND_BONDED }.getOrDefault(true)
            val waitS = if (bonded) 3L else 30L
            if (!cccdLatch.await(waitS, TimeUnit.SECONDS)) {
                throw IOException(
                    if (bonded) "ble: enable notifications timed out"
                    else "ble: the printer asks to pair with this phone; accept the pairing request and print again",
                )
            }
        }

        @SuppressLint("MissingPermission")
        fun write(data: ByteArray, off: Int, len: Int) {
            if (!connected) throw IOException("ble: link dropped")
            writeLatch = CountDownLatch(1)
            write.writeType = if (write.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0) {
                BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            } else {
                BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
            }
            write.value = data.copyOfRange(off, off + len)
            if (!gatt.writeCharacteristic(write)) throw IOException("ble: write rejected")
            writeLatch.await(2, TimeUnit.SECONDS) // pace; no-response writes still call back
        }
    }

    /** Connect, discover the print service and return an open (not yet subscribed) session. */
    @SuppressLint("MissingPermission")
    private fun connectSession(ctx: Context, mac: String): Session {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: throw IOException("Bluetooth not available")
        if (!adapter.isEnabled) throw IOException("Bluetooth is off")
        val device = adapter.getRemoteDevice(mac)

        val connectLatch = CountDownLatch(1)
        val discoverLatch = CountDownLatch(1)
        // Set in the callback before its latch.countDown(); read after await — the
        // latch establishes the happens-before, so plain vars are safe here.
        var connected = false
        var discovered = false
        var session: Session? = null

        val cb = object : BluetoothGattCallback() {
            override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    connected = true
                    g.discoverServices()
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    connected = false
                    session?.connected = false // a pooled session the printer dropped
                    connectLatch.countDown(); discoverLatch.countDown()
                }
            }

            override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
                discovered = status == BluetoothGatt.GATT_SUCCESS
                connectLatch.countDown(); discoverLatch.countDown()
            }

            override fun onMtuChanged(g: BluetoothGatt, mtu: Int, status: Int) {
                Log.i(TAG, "ble mtu ${g.device.address}: $mtu (status $status)")
                if (status == BluetoothGatt.GATT_SUCCESS) session?.chunk = (mtu - 3).coerceIn(20, MAX_CHUNK)
                session?.mtuLatch?.countDown()
            }

            override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
                Log.i(TAG, "ble subscribe on ${g.device.address}: status $status")
                session?.cccdStatus = status
                session?.cccdLatch?.countDown()
            }

            override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
                session?.writeLatch?.countDown()
            }

            @Suppress("DEPRECATION") // pre-API-33 callback; value arg added in 33
            override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
                if (c.uuid == session?.notify?.uuid) session?.notifications?.offer(c.value?.clone() ?: ByteArray(0))
            }
        }

        val gatt = device.connectGatt(ctx, false, cb, android.bluetooth.BluetoothDevice.TRANSPORT_LE)
            ?: throw IOException("ble: connectGatt returned null")
        try {
            if (!connectLatch.await(15, TimeUnit.SECONDS) || !connected) throw IOException("ble: connect timed out")
            if (!discoverLatch.await(10, TimeUnit.SECONDS) || !discovered) throw IOException("ble: service discovery failed")
            // FF00/FF02/FF03 when the printer has them, else the first writable and
            // notifying characteristics (GattChoice, superprinter_flutter's rule).
            val all = gatt.services.flatMap { sv -> sv.characteristics.map { sv to it } }
            val chars = all.map { (sv, c) -> GattChoice.Char(sv.uuid.toString(), c.uuid.toString(), c.properties) }
            val wc = GattChoice.write(chars) ?: throw IOException("ble: no writable characteristic")
            val nc = GattChoice.notify(chars, wc) ?: throw IOException("ble: no notify characteristic")
            fun real(ch: GattChoice.Char) = all.first { (sv, c) -> sv.uuid.toString() == ch.service && c.uuid.toString() == ch.uuid }.second
            val w = real(wc)
            val n = real(nc)
            val s = Session(gatt, w, n)
            session = s
            // A write longer than the link's MTU less 3 is cut short without an
            // error (write without response), so the printer gets a broken job:
            // ask for the largest MTU and write in chunks of what was agreed.
            if (gatt.requestMtu(517)) s.mtuLatch.await(3, TimeUnit.SECONDS)
            Log.i(TAG, "ble writes to $mac in chunks of ${s.chunk}")
            Log.i(TAG, "ble session to $mac opened")
            return s
        } catch (e: Exception) {
            runCatching { gatt.disconnect() }
            runCatching { gatt.close() }
            throw e
        }
    }
}
