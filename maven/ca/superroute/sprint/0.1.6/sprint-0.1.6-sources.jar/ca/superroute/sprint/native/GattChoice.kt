package ca.superroute.sprint.native

/**
 * Which characteristics of a BLE printer sPrint writes to and listens on —
 * superprinter_flutter's rule (its iOS printing): the characteristic whose UUID
 * is 0xFF02 (FF00 print service), else the first writable one; for status the
 * 0xFF03 characteristic, else the first that notifies. Pure, so recorded GATT
 * layouts are tested on the JVM.
 */
object GattChoice {
    const val PROP_WRITE_NO_RESPONSE = 0x04
    const val PROP_WRITE = 0x08
    const val PROP_NOTIFY = 0x10
    const val PROP_INDICATE = 0x20

    data class Char(val service: String, val uuid: String, val properties: Int) {
        val writable get() = properties and (PROP_WRITE or PROP_WRITE_NO_RESPONSE) != 0
        val withoutResponse get() = properties and PROP_WRITE_NO_RESPONSE != 0
        val notifies get() = properties and (PROP_NOTIFY or PROP_INDICATE) != 0
    }

    @JvmStatic
    fun write(chars: List<Char>): Char? =
        chars.firstOrNull { it.writable && it.uuid.lowercase().contains("0000ff02") } ?: chars.firstOrNull { it.writable }

    @JvmStatic
    fun notify(chars: List<Char>, write: Char?): Char? =
        chars.firstOrNull { it.notifies && it.uuid.lowercase().contains("0000ff03") }
            ?: chars.firstOrNull { it.notifies && write != null && it.service == write.service }
            ?: chars.firstOrNull { it.notifies }
}
