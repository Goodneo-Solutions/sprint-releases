package ca.superroute.sprint.native

import org.json.JSONArray
import org.json.JSONObject
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress

/**
 * One DNS-SD service instance as the core's MDNSBrowser / MDNSAdvertiser carry it
 * ({"instance", "service", "domain", "host", "port", "txt": ["k=v", …]}). Plain
 * Kotlin (no Android classes), so it is unit-tested on the JVM.
 */
internal data class MdnsService(
    val instance: String,
    val service: String = SERVICE_TYPE,
    val domain: String = "local.",
    val host: String = "",
    val port: Int = 0,
    val txt: List<String> = emptyList(),
) {
    fun toJson(): JSONObject = JSONObject()
        .put("instance", instance).put("service", service).put("domain", domain)
        .put("host", host).put("port", port).put("txt", JSONArray(txt))

    /** The TXT entries as key / value pairs, in order (an entry without "=" has an empty value). */
    val attributes: List<Pair<String, String>> get() = txt.mapNotNull(::splitTxt)

    companion object {
        const val SERVICE_TYPE = "_superprinter._tcp"

        fun fromJson(o: JSONObject): MdnsService {
            val a = o.optJSONArray("txt")
            val txt = if (a == null) emptyList() else (0 until a.length()).map { a.optString(it) }
            return MdnsService(
                o.optString("instance"), o.optString("service").ifEmpty { SERVICE_TYPE }, o.optString("domain").ifEmpty { "local." },
                o.optString("host"), o.optInt("port"), txt,
            )
        }

        /** A browse result for the core: a JSON array of services. */
        fun listJson(list: List<MdnsService>): String = JSONArray(list.map { it.toJson() }).toString()

        /** Whether an NSD service type ("_superprinter._tcp.", "._superprinter._tcp") is [type]. */
        fun sameType(nsdType: String?, type: String = SERVICE_TYPE): Boolean =
            nsdType != null && nsdType.trim('.').equals(type.trim('.'), ignoreCase = true)

        /** TXT entries "k=v" from NsdServiceInfo attributes (a null value is a bare key). */
        fun txtFromAttributes(attrs: Map<String, ByteArray?>?): List<String> {
            if (attrs == null) return emptyList()
            // NsdServiceInfo's attributes are an ArrayMap whose entry set refuses toArray():
            // copy by iterating.
            val pairs = ArrayList<Pair<String, ByteArray?>>()
            val it = attrs.entries.iterator()
            while (it.hasNext()) {
                val e = it.next()
                pairs.add(e.key to e.value)
            }
            pairs.sortBy { order(it.first) }
            return pairs.map { (k, v) -> if (v == null) k else "$k=${String(v, Charsets.UTF_8)}" }
        }

        /**
         * A TXT value cut to what NsdServiceInfo.setAttribute takes: key + value
         * under 255 bytes, never splitting a UTF-8 character.
         */
        fun fitValue(key: String, value: String): String {
            val max = 254 - key.toByteArray(Charsets.UTF_8).size
            if (max <= 0) return ""
            if (value.toByteArray(Charsets.UTF_8).size <= max) return value
            val sb = StringBuilder()
            var used = 0
            var i = 0
            while (i < value.length) {
                val cp = value.codePointAt(i)
                val s = String(Character.toChars(cp))
                val n = s.toByteArray(Charsets.UTF_8).size
                if (used + n > max) break
                sb.append(s)
                used += n
                i += Character.charCount(cp)
            }
            return sb.toString()
        }

        /**
         * The address a browse reports for a resolved service: a routable IPv4
         * first, then IPv6 (global before link-local, which keeps its scope), then
         * anything; "" when there is none.
         */
        fun pickAddress(addrs: List<InetAddress>): String {
            val best = addrs.firstOrNull { it is Inet4Address && !it.isLoopbackAddress && !it.isLinkLocalAddress }
                ?: addrs.firstOrNull { it is Inet4Address }
                ?: addrs.firstOrNull { it is Inet6Address && !it.isLinkLocalAddress && !it.isLoopbackAddress }
                ?: addrs.firstOrNull()
                ?: return ""
            return best.hostAddress.orEmpty()
        }

        private fun splitTxt(e: String): Pair<String, String>? {
            if (e.isEmpty()) return null
            val i = e.indexOf('=')
            return if (i < 0) e to "" else if (i == 0) null else e.substring(0, i) to e.substring(i + 1)
        }

        // The protocol's keys in its order (v, fp, name, mode, agent), others after.
        private val KEY_ORDER = listOf("v", "fp", "name", "mode", "agent")
        private fun order(k: String): Int = KEY_ORDER.indexOf(k).let { if (it < 0) KEY_ORDER.size else it }
    }
}
