package ca.superroute.sprint

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import ca.superroute.sprint.core.Core
import ca.superroute.sprint.native.Usb
import org.json.JSONArray
import org.json.JSONObject

/**
 * Finding printers: the network through the core (TCP 631 / 9100, named by SNMP),
 * Bluetooth, BLE and USB through Android. The host holds the runtime permissions
 * (BLUETOOTH_CONNECT / BLUETOOTH_SCAN on API 31+).
 */
object Discovery {
    /** This device's private /24 prefixes ("192.168.1"). */
    @JvmStatic fun localPrefixes(): List<String> = JSONArray(Core.localPrefixes()).strings()

    /** Printers answering on IPP (631) or raw (9100) in a /24; null scans every local one. */
    @JvmStatic
    fun scanNetwork(prefix: String? = null, timeoutMs: Int = 350): List<DiscoveredPrinter> {
        val a = JSONObject(Core.scanNetwork(prefix ?: "", timeoutMs.toLong())).optJSONArray("printers") ?: JSONArray()
        return (0 until a.length()).map { DiscoveredPrinter.fromJson(a.getJSONObject(it)) }
    }

    /**
     * The devices bonded with this phone, every one (the user paired them), on the
     * transports its type says: classic, LE or both. Marked by the core (likely
     * printer, known model). Needs BLUETOOTH_CONNECT on API 31+.
     */
    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    @JvmStatic
    fun bondedPrinters(): List<DiscoveredPrinter> {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return emptyList()
        val list = try { adapter.bondedDevices.orEmpty() } catch (_: SecurityException) { return emptyList() }
        return merge(list.flatMap { d -> sightings(d, d.name, null, 0, bonded = true) })
    }

    /**
     * Bluetooth LE devices seen in [scanMs], every one (no filter, as the SuperPrinter
     * app's discovery): name, address and advertised service UUIDs, marked by the core
     * and likely printers first. [anyDevice] is kept for compatibility (always all).
     */
    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION", "UNUSED_PARAMETER")
    @JvmStatic
    fun scanBle(scanMs: Long = 4000, anyDevice: Boolean = true): List<DiscoveredPrinter> = merge(rawBleScan(scanMs))

    /**
     * Classic discovery for [scanMs] (BluetoothAdapter.startDiscovery): every device
     * the inquiry reports — Android reports LE-only devices here too — with its Class
     * of Device. Needs BLUETOOTH_SCAN (API 31+) or ACCESS_FINE_LOCATION (API ≤ 30).
     */
    @JvmStatic
    fun scanClassic(context: Context, scanMs: Long = 10000): List<DiscoveredPrinter> = merge(rawClassicScan(context, scanMs))

    /**
     * Every Bluetooth device nearby, each once: bonded devices, classic discovery and an
     * LE scan run together for [scanMs]; a printer seen over both lists its
     * transports, and transport/host are the one SuperPrinter prefers for it.
     */
    @JvmStatic
    fun nearbyBluetooth(context: Context, scanMs: Long = 8000): List<DiscoveredPrinter> {
        val pool = java.util.concurrent.Executors.newFixedThreadPool(2)
        try {
            val classic = pool.submit<List<DiscoveredPrinter>> { rawClassicScan(context, scanMs) }
            val le = pool.submit<List<DiscoveredPrinter>> { rawBleScan(scanMs) }
            val bonded = BluetoothAdapter.getDefaultAdapter()?.let { a ->
                try { a.bondedDevices.orEmpty() } catch (_: SecurityException) { emptySet() }
            }.orEmpty().flatMap { sightings(it, it.name, null, 0, bonded = true) }
            return merge(bonded + classic.get() + le.get())
        } finally {
            pool.shutdown()
        }
    }

    /** The runtime permissions Bluetooth discovery needs on this Android version (as the SuperPrinter app asks). */
    @JvmStatic
    fun bluetoothPermissions(): Array<String> =
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            arrayOf("android.permission.BLUETOOTH_SCAN", "android.permission.BLUETOOTH_CONNECT")
        } else {
            arrayOf("android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION")
        }

    /** The core's merge and marks over raw sightings (likely printers first). */
    @JvmStatic
    fun merge(found: List<DiscoveredPrinter>): List<DiscoveredPrinter> {
        if (found.isEmpty()) return emptyList()
        val a = JSONObject(Core.mergeBluetooth(JSONArray(found.map { it.toJson() }).toString())).optJSONArray("printers") ?: JSONArray()
        return (0 until a.length()).map { DiscoveredPrinter.fromJson(a.getJSONObject(it)) }
    }

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    private fun rawBleScan(scanMs: Long): List<DiscoveredPrinter> {
        val scanner = BluetoothAdapter.getDefaultAdapter()?.takeIf { it.isEnabled }?.bluetoothLeScanner ?: return emptyList()
        val found = LinkedHashMap<String, DiscoveredPrinter>()
        val cb = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val bytes = result.scanRecord?.bytes
                val ad = if (bytes != null) Advertisement.parse(bytes) else Advertisement(null, emptyList())
                val name = ad.name ?: runCatching { result.device.name }.getOrNull()
                synchronized(found) {
                    val before = found[result.device.address]
                    val p = advertised(result.device.address, name ?: before?.name, ad.services.ifEmpty { before?.services.orEmpty() })
                    found[result.device.address] = p
                }
            }
        }
        val settings = android.bluetooth.le.ScanSettings.Builder()
            .setScanMode(android.bluetooth.le.ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        try {
            scanner.startScan(null, settings, cb)
        } catch (_: SecurityException) {
            return emptyList()
        }
        try {
            Thread.sleep(scanMs)
        } finally {
            runCatching { scanner.stopScan(cb) }
        }
        return synchronized(found) { found.values.toList() }
    }

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    private fun rawClassicScan(context: Context, scanMs: Long): List<DiscoveredPrinter> {
        val adapter = BluetoothAdapter.getDefaultAdapter()?.takeIf { it.isEnabled } ?: return emptyList()
        val found = LinkedHashMap<String, List<DiscoveredPrinter>>()
        val done = java.util.concurrent.CountDownLatch(1)
        val receiver = object : android.content.BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: android.content.Intent) {
                when (intent.action) {
                    BluetoothDevice.ACTION_FOUND -> {
                        val d: BluetoothDevice = if (android.os.Build.VERSION.SDK_INT >= 33) {
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                        } else {
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                        } ?: return
                        val cls: android.bluetooth.BluetoothClass? = if (android.os.Build.VERSION.SDK_INT >= 33) {
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_CLASS, android.bluetooth.BluetoothClass::class.java)
                        } else {
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_CLASS)
                        }
                        val name = intent.getStringExtra(BluetoothDevice.EXTRA_NAME) ?: runCatching { d.name }.getOrNull()
                        val cod = cls?.let { classOfDevice(it) } ?: 0
                        synchronized(found) { found[d.address] = sightings(d, name, null, cod, bonded = false) }
                    }
                    BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> done.countDown()
                }
            }
        }
        val filter = android.content.IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
        }
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            context.registerReceiver(receiver, filter)
        }
        try {
            try {
                if (adapter.isDiscovering) adapter.cancelDiscovery()
                if (!adapter.startDiscovery()) return emptyList()
            } catch (_: SecurityException) {
                return emptyList()
            }
            done.await(scanMs, java.util.concurrent.TimeUnit.MILLISECONDS)
        } finally {
            runCatching { adapter.cancelDiscovery() }
            runCatching { context.unregisterReceiver(receiver) }
        }
        return synchronized(found) { found.values.flatten() }
    }

    /** One device as sightings per transport its type says (dual mode: both). */
    @SuppressLint("MissingPermission")
    private fun sightings(d: BluetoothDevice, name: String?, services: List<String>?, cod: Int, bonded: Boolean): List<DiscoveredPrinter> {
        val type = runCatching { d.type }.getOrDefault(BluetoothDevice.DEVICE_TYPE_UNKNOWN)
        val n = name?.takeIf { it.isNotBlank() } ?: d.address
        val ts = when (type) {
            BluetoothDevice.DEVICE_TYPE_LE -> listOf(Transports.BLE)
            BluetoothDevice.DEVICE_TYPE_DUAL -> listOf(Transports.BLUETOOTH, Transports.BLE)
            else -> listOf(Transports.BLUETOOTH)
        }
        return ts.map { t ->
            DiscoveredPrinter(n, d.address, t, bonded = bonded, keys = PrinterKeys(listOf(n)), services = services.orEmpty(), classOfDevice = cod)
        }
    }

    /** An LE advertisement as a sighting (pure: the JVM tests feed recorded adverts through it). */
    @JvmStatic
    fun advertised(mac: String, name: String?, services: List<String>): DiscoveredPrinter {
        val n = name?.takeIf { it.isNotBlank() } ?: mac
        return DiscoveredPrinter(n, mac, Transports.BLE, keys = PrinterKeys(listOf(n)), services = services)
    }

    private fun classOfDevice(c: android.bluetooth.BluetoothClass): Int {
        // BluetoothClass hides the raw value; its parts rebuild the 24-bit CoD.
        var cod = c.deviceClass and 0x1ffc
        for (bit in 13..23) if (c.hasService(1 shl bit)) cod = cod or (1 shl bit)
        return cod
    }

    /** USB devices with a printer (or bulk OUT) interface, with their permission state. */
    @JvmStatic
    fun usbPrinters(context: Context): List<DiscoveredPrinter> {
        val mgr = context.getSystemService(Context.USB_SERVICE) as android.hardware.usb.UsbManager
        return mgr.deviceList.values.filter { Usb.endpoints(it) != null }.map { d ->
            val name = runCatching { d.productName }.getOrNull()?.takeIf { it.isNotBlank() } ?: Usb.hostOf(d)
            val permitted = mgr.hasPermission(d)
            DiscoveredPrinter(
                name, Usb.hostOf(d), Transports.USB, permitted = permitted,
                keys = PrinterKeys(listOf(name), "%04x:%04x".format(d.vendorId, d.productId), if (permitted) Usb.deviceId(context, d) else null),
            )
        }
    }
}
