package ca.superroute.sprint

/**
 * A Bluetooth LE advertisement read from its raw bytes (the AD structures of
 * the advertising and scan-response data): the device's name and the service
 * UUIDs it lists. Pure Kotlin, so recorded adverts are tested on the JVM.
 */
data class Advertisement(val name: String?, val services: List<String>) {
    companion object {
        private const val BASE = "-0000-1000-8000-00805f9b34fb"

        @JvmStatic
        fun parse(bytes: ByteArray): Advertisement {
            var name: String? = null
            val services = ArrayList<String>()
            var i = 0
            while (i < bytes.size) {
                val len = bytes[i].toInt() and 0xff
                if (len == 0 || i + 1 + len > bytes.size) break
                val type = bytes[i + 1].toInt() and 0xff
                val data = bytes.copyOfRange(i + 2, i + 1 + len)
                when (type) {
                    0x02, 0x03 -> for (j in 0 until data.size / 2) {
                        val v = (data[j * 2].toInt() and 0xff) or ((data[j * 2 + 1].toInt() and 0xff) shl 8)
                        services += "0000%04x$BASE".format(v)
                    }
                    0x04, 0x05 -> for (j in 0 until data.size / 4) {
                        var v = 0L
                        for (k in 3 downTo 0) v = (v shl 8) or (data[j * 4 + k].toLong() and 0xff)
                        services += "%08x$BASE".format(v)
                    }
                    0x06, 0x07 -> for (j in 0 until data.size / 16) {
                        val b = data.copyOfRange(j * 16, j * 16 + 16).reversedArray()
                        val h = b.joinToString("") { "%02x".format(it.toInt() and 0xff) }
                        services += "${h.substring(0, 8)}-${h.substring(8, 12)}-${h.substring(12, 16)}-${h.substring(16, 20)}-${h.substring(20)}"
                    }
                    0x08 -> if (name == null) name = String(data, Charsets.UTF_8)
                    0x09 -> name = String(data, Charsets.UTF_8)
                }
                i += 1 + len
            }
            return Advertisement(name?.trimEnd('\u0000'), services.distinct())
        }
    }
}
