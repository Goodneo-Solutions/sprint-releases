package ca.superroute.sprint

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject

/** Transports a [TargetPrinter] can name. */
object Transports {
    /** Raw TCP (JetDirect / 9100); host is "ip" or "ip:port". */
    const val NETWORK = "network"
    /** Classic Bluetooth RFCOMM (SPP); host is the MAC address. */
    const val BLUETOOTH = "bluetooth"
    /** Bluetooth LE (GATT); host is the MAC address. */
    const val BLE = "ble"
    /** USB host; host is "VID:PID[:SERIAL]" in hex. */
    const val USB = "usb"
}

/** Printer command languages. */
object Languages {
    const val ESCPOS = "escpos"
    const val XPRINTER = "xprinter"
    const val TSPL = "tspl"
    const val ZPL = "zpl"
    const val CPCL = "cpcl"
    const val XPP = "xpp"
    const val HPRT = "hprt"
    const val PL = "pl"
    const val TP108 = "tp108"
    /** A document printer that takes the PDF itself. */
    const val PDF = "pdf"
}

/** Job types of a [PrintJob]. */
object JobTypes {
    const val LABEL = "label"
    const val RAW = "raw"
    const val PDF = "pdf"
    const val HTML = "html"
    const val IMAGE = "image"
    const val TEST = "test"
}

/** The names, USB id and IEEE-1284 device ID a printer goes by. */
data class PrinterKeys(val names: List<String> = emptyList(), val usb: String? = null, val deviceId: String? = null) {
    fun toJson(): JSONObject = JSONObject().apply {
        if (names.isNotEmpty()) put("names", JSONArray(names))
        usb?.let { put("usb", it) }
        deviceId?.let { put("device_id", it) }
    }

    companion object {
        fun fromJson(o: JSONObject?): PrinterKeys? = o?.let {
            PrinterKeys(it.optJSONArray("names").strings(), it.optStringOrNull("usb"), it.optStringOrNull("device_id"))
        }
    }
}

/**
 * A configured printer. The JSON keys are the ones the SuperPrinter Android app and
 * superprinter_flutter persist. Zero / null means "not known": dpi 0 is 203 (XPP
 * 300), width 0 keeps the page's own width, a null TSPL2 / Xprinter setting keeps
 * the family's stock preset.
 */
data class TargetPrinter(
    val name: String,
    val host: String = "",
    val transport: String = Transports.NETWORK,
    val isDefault: Boolean = false,
    val language: String = "",
    val widthDots: Int = 0,
    val paperWidthMm: Int = 0,
    val paperHeightMm: Int = 0,
    val dpi: Int = 0,
    val compress: Boolean = false,
    val plGapMm: Int? = null,
    val plDensity: Int? = null,
    val plDirection: Int? = null,
    val xpCut: String? = null,
    val xpDensity: Int? = null,
    val channel: Int = 0,
    val languageSource: String? = null,
    val evidence: PrinterKeys? = null,
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("name", name)
        put("host", host)
        put("transport", transport)
        if (isDefault) put("default", true)
        put("language", language)
        if (widthDots != 0) put("width_dots", widthDots)
        if (paperWidthMm != 0) put("paper_width_mm", paperWidthMm)
        if (paperHeightMm != 0) put("paper_height_mm", paperHeightMm)
        if (dpi != 0) put("dpi", dpi)
        if (compress) put("compress", true)
        plGapMm?.let { put("pl_gap_mm", it) }
        plDensity?.let { put("pl_density", it) }
        plDirection?.let { put("pl_direction", it) }
        xpCut?.let { put("xp_cut", it) }
        xpDensity?.let { put("xp_density", it) }
        if (channel != 0) put("channel", channel)
        languageSource?.let { put("language_source", it) }
        evidence?.let { put("evidence", it.toJson()) }
    }

    companion object {
        fun fromJson(o: JSONObject): TargetPrinter = TargetPrinter(
            name = o.optString("name"),
            host = o.optString("host"),
            transport = o.optString("transport").ifEmpty { Transports.NETWORK },
            isDefault = o.optBoolean("default"),
            language = o.optString("language"),
            widthDots = o.optInt("width_dots"),
            paperWidthMm = o.optInt("paper_width_mm"),
            paperHeightMm = o.optInt("paper_height_mm"),
            dpi = o.optInt("dpi"),
            compress = o.optBoolean("compress"),
            plGapMm = o.optIntOrNull("pl_gap_mm"),
            plDensity = o.optIntOrNull("pl_density"),
            plDirection = o.optIntOrNull("pl_direction"),
            xpCut = o.optStringOrNull("xp_cut"),
            xpDensity = o.optIntOrNull("xp_density"),
            channel = o.optInt("channel"),
            languageSource = o.optStringOrNull("language_source"),
            evidence = PrinterKeys.fromJson(o.optJSONObject("evidence")),
        )
    }
}

/**
 * A label described as primitives placed in millimetres (version 1), kept as its
 * JSON — the shape the Superroute server and every sPrint platform share.
 */
class LabelJob private constructor(internal val json: JSONObject) {
    val widthMm: Double get() = json.optDouble("width_mm")
    val heightMm: Double get() = json.optDouble("height_mm")
    override fun toString(): String = json.toString()

    companion object {
        /** Reads a label from its JSON. */
        fun parse(json: String): LabelJob = LabelJob(JSONObject(json))

        /** A label of [widthMm] × [heightMm] with the given elements (each a JSON object). */
        fun of(widthMm: Double, heightMm: Double, elements: List<JSONObject>): LabelJob =
            LabelJob(JSONObject().put("version", 1).put("width_mm", widthMm).put("height_mm", heightMm).put("elements", JSONArray(elements)))
    }
}

/** One thing to print. */
data class PrintJob(
    val type: String,
    val printer: String? = null,
    val label: LabelJob? = null,
    val data: ByteArray? = null,
    val html: String? = null,
    val baseUrl: String? = null,
    val text: String? = null,
    val copies: Int = 1,
    val duplex: String? = null,
    val paper: String? = null,
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("type", type)
        printer?.let { put("printer", it) }
        label?.let { put("label", it.json) }
        data?.let { put("data", Base64.encodeToString(it, Base64.NO_WRAP)) }
        html?.let { put("html", it) }
        baseUrl?.let { put("base_url", it) }
        text?.let { put("text", it) }
        put("copies", copies)
        duplex?.let { put("duplex", it) }
        paper?.let { put("paper", it) }
    }

    override fun equals(other: Any?): Boolean = other is PrintJob && toJson().toString() == other.toJson().toString()
    override fun hashCode(): Int = toJson().toString().hashCode()
}

/** The outcome of a print. */
data class PrintResult(
    val ok: Boolean,
    /** transient, printer_offline, printer_disabled, download_failed, unsupported, print_error or stopped. */
    val reason: String?,
    val message: String?,
    val printer: String?,
    val language: String?,
    /** stream, raw, passthrough, driver or html. */
    val path: String?,
    val bytes: Int,
) {
    companion object {
        fun fromJson(o: JSONObject) = PrintResult(
            o.optBoolean("ok"), o.optStringOrNull("reason"), o.optStringOrNull("message"), o.optStringOrNull("printer"),
            o.optStringOrNull("language"), o.optStringOrNull("path"), o.optInt("bytes"),
        )
    }
}

/** A printer found by discovery. */
data class DiscoveredPrinter(
    val name: String,
    val host: String,
    val transport: String,
    val ipp: Boolean = false,
    val raw: Boolean = false,
    val bonded: Boolean = false,
    /** USB only: whether the device permission is already granted. */
    val permitted: Boolean = true,
    val keys: PrinterKeys? = null,
    /** Bluetooth LE: the service UUIDs it advertises. */
    val services: List<String> = emptyList(),
    /** Bluetooth: every transport it was seen on, and its address on each (transport/host: the preferred one). */
    val transports: List<String> = emptyList(),
    val hosts: Map<String, String> = emptyMap(),
    /** Classic Bluetooth: the Class of Device (0 unknown). */
    val classOfDevice: Int = 0,
    /** Bluetooth: every device found is listed; this marks the likely printers. */
    val likelyPrinter: Boolean = false,
    /** The model-table entry the name matched, with its language. */
    val known: PrinterIdentity? = null,
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("name", name).put("host", host).put("transport", transport)
        if (ipp) put("ipp", true)
        if (raw) put("raw", true)
        if (bonded) put("bonded", true)
        keys?.let { put("keys", it.toJson()) }
        if (services.isNotEmpty()) put("services", JSONArray(services))
        if (transports.isNotEmpty()) put("transports", JSONArray(transports))
        if (hosts.isNotEmpty()) put("hosts", JSONObject(hosts as Map<*, *>))
        if (classOfDevice != 0) put("class_of_device", classOfDevice)
        if (likelyPrinter) put("likely_printer", true)
        if (!permitted) put("permitted", false)
        known?.let { k ->
            put("known", JSONObject().apply {
                k.language?.let { put("language", it) }
                if (k.dpi > 0) put("dpi", k.dpi)
                if (k.widthMm > 0) put("width_mm", k.widthMm)
                k.kind?.let { put("kind", it) }
                k.source?.let { put("source", it) }
                k.model?.let { put("model", it) }
            })
        }
    }

    companion object {
        fun fromJson(o: JSONObject) = DiscoveredPrinter(
            o.optString("name"), o.optString("host"), o.optString("transport"), o.optBoolean("ipp"), o.optBoolean("raw"),
            o.optBoolean("bonded"), true, PrinterKeys.fromJson(o.optJSONObject("keys")),
            o.optJSONArray("services").strings(), o.optJSONArray("transports").strings(),
            o.optJSONObject("hosts")?.let { h -> h.keys().asSequence().associateWith { h.optString(it) } } ?: emptyMap(),
            o.optInt("class_of_device"), o.optBoolean("likely_printer"),
            o.optJSONObject("known")?.let { PrinterIdentity.fromJson(it) },
        )
    }
}

/** What identification worked out about a printer, and from what (device_id, model_table, status, user, none). */
data class PrinterIdentity(val language: String?, val dpi: Int, val widthMm: Int, val kind: String?, val source: String?, val model: String?) {
    companion object {
        fun fromJson(o: JSONObject) = PrinterIdentity(
            o.optStringOrNull("language"), o.optInt("dpi"), o.optInt("width_mm"), o.optStringOrNull("kind"),
            o.optStringOrNull("source"), o.optStringOrNull("model"),
        )
    }
}

/** A back-channel identification: the language and the reply that proved it. */
data class Probe(val language: String, val evidence: String)

/** What a print node keeps between runs: persist [json] on every [NodeEvent.State]. */
data class NodeState(val json: JSONObject) {
    val server: String get() = json.optString("server")
    val nodeToken: String? get() = json.optStringOrNull("node_token")
    val nodeId: Long get() = json.optLong("node_id")
    val name: String? get() = json.optStringOrNull("name")
    val paired: Boolean get() = !nodeToken.isNullOrEmpty()

    companion object {
        fun of(server: String = "https://api.superroute.ca") = NodeState(JSONObject().put("server", server))
        fun parse(json: String) = NodeState(JSONObject(json))
    }
}

/** A protocol sweep the node runs, for a banner (Next / Stop / choose through [PrintNode.sweepPress]). */
data class SweepView(val sweep: Long, val printer: String, val status: String?, val position: Int, val count: Int, val printed: Int, val json: JSONObject) {
    companion object {
        fun fromJson(o: JSONObject): SweepView {
            val st = o.optJSONObject("state") ?: JSONObject()
            return SweepView(o.optLong("sweep"), o.optString("printer"), st.optStringOrNull("status"), st.optInt("position"),
                st.optInt("count"), o.optInt("printed"), o)
        }
    }
}

/** What the client locked for one printer on the Print Nodes page. */
data class PrinterLock(val language: Boolean, val path: Boolean)

/**
 * What the server holds for the node's printers, as the last heartbeat
 * answered: [languages] the operator's choices ("auto" = the node's
 * identification), [locks] what the client locked, [paper] each printer's
 * default paper. Already applied by the node.
 */
data class PrinterSettings(val languages: Map<String, String>, val locks: Map<String, PrinterLock>, val paper: Map<String, String>) {
    /** Whether the client locked [printer]'s language. */
    fun languageLocked(printer: String) = locks[printer]?.language == true

    companion object {
        fun fromJson(o: JSONObject): PrinterSettings {
            fun strings(m: JSONObject?) = m?.keys()?.asSequence()?.associateWith { m.optString(it) } ?: emptyMap()
            val l = o.optJSONObject("locks")
            val locks = l?.keys()?.asSequence()?.associateWith {
                val v = l.optJSONObject(it) ?: JSONObject()
                PrinterLock(v.optBoolean("language"), v.optBoolean("path"))
            } ?: emptyMap()
            return PrinterSettings(strings(o.optJSONObject("languages")), locks, strings(o.optJSONObject("paper")))
        }
    }
}

/**
 * A job that started or ended printing ([state] "started" | "ended"): a cloud
 * job ([source] "cloud", [jobId] the server's id) or one a LAN peer sent
 * ([source] "peer", [peer] its name). [result] is set when it ended.
 */
data class PrintingEvent(
    val state: String, val source: String, val jobId: Long, val peer: String?, val printer: String, val at: String,
    val result: PrintResult?,
) {
    val started: Boolean get() = state == "started"

    companion object {
        fun fromJson(o: JSONObject) = PrintingEvent(
            o.optString("state"), o.optString("source"), o.optLong("job_id"), o.optStringOrNull("peer"), o.optString("printer"),
            o.optString("at"), o.optJSONObject("result")?.let { PrintResult.fromJson(it) },
        )
    }
}

/** A remote command the server sent the node (id, action, params). */
data class NodeCommand(val id: Long, val action: String, val params: JSONObject) {
    companion object {
        fun fromJson(o: JSONObject) = NodeCommand(o.optLong("id"), o.optString("action"), o.optJSONObject("params") ?: JSONObject())
    }
}

/** A host's answer to a [NodeCommand]: [error] set fails it (with [output] kept beside). */
data class CommandAnswer(val output: String = "", val error: String? = null) {
    internal fun toJson(): JSONObject = JSONObject().put("handled", true).put("output", output).apply { error?.let { put("error", it) } }
}

/** What a ZPL printer told about its media: resolution, and width / length when it named them (0 otherwise). */
data class ZplMedia(val dpi: Int, val widthMm: Int, val lengthMm: Int, val widthDots: Int, val lengthDots: Int) {
    companion object {
        fun fromJson(o: JSONObject) = ZplMedia(
            o.optInt("dpi"), o.optInt("width_mm"), o.optInt("length_mm"), o.optInt("width_dots"), o.optInt("length_dots"),
        )
    }
}

/** What a print node reports while it runs. */
sealed class NodeEvent {
    data class State(val state: NodeState) : NodeEvent()
    data class Job(val jobId: Long, val result: PrintResult) : NodeEvent()
    data class Log(val message: String) : NodeEvent()
    data class Sweep(val sweep: SweepView) : NodeEvent()
    /** The server's printer settings changed (already applied). */
    data class Settings(val settings: PrinterSettings) : NodeEvent()
    /** A job started or ended printing. */
    data class Printing(val printing: PrintingEvent) : NodeEvent()
}

/** An error sPrint reported. */
class SPrintException(message: String) : Exception(message)

internal fun JSONObject.optStringOrNull(key: String): String? = if (has(key) && !isNull(key)) optString(key).ifEmpty { null } else null
internal fun JSONObject.optIntOrNull(key: String): Int? = if (has(key) && !isNull(key)) optInt(key) else null
internal fun JSONArray?.strings(): List<String> = if (this == null) emptyList() else (0 until length()).map { getString(it) }
